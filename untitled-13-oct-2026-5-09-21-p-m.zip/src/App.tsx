/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { CalamburAvatar } from './components/Avatar';
import { SocialLinks } from './components/SocialLinks';
import { Projects } from './components/Projects';
import { Activity } from './components/Activity';
import { Skills } from './components/Skills';
import { Work } from './components/Work';
import { Blog } from './components/Blog';
import { Newsletter } from './components/Newsletter';
import { ContactModal } from './components/ContactModal';
import { ProjectModal } from './components/ProjectModal';
import { BlogModal } from './components/BlogModal';
import { AvatarModal } from './components/AvatarModal';
import { ScrollProgressBar } from './components/ScrollProgressBar';
import { translations, Language } from './data/translations';

export default function App() {
  const [lang, setLang] = useState<Language>('en');
  const [theme, setTheme] = useState<'dark' | 'light' | 'system'>('dark');
  
  // Modals state
  const [isContactOpen, setIsContactOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState<string | null>(null);
  const [selectedArticleId, setSelectedArticleId] = useState<number | null>(null);
  const [isAvatarOpen, setIsAvatarOpen] = useState(false);

  // Sync theme with document.documentElement for Tailwind dark/light classes
  useEffect(() => {
    const root = document.documentElement;
    const applyTheme = (isDark: boolean) => {
      if (isDark) {
        root.classList.add('dark');
        root.classList.remove('light');
      } else {
        root.classList.add('light');
        root.classList.remove('dark');
      }
    };

    if (theme === 'system') {
      const media = window.matchMedia('(prefers-color-scheme: dark)');
      applyTheme(media.matches);

      const listener = (e: MediaQueryListEvent) => applyTheme(e.matches);
      media.addEventListener('change', listener);
      return () => media.removeEventListener('change', listener);
    } else {
      applyTheme(theme === 'dark');
    }
  }, [theme]);

  const t = translations[lang];

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      theme === 'light' ? 'bg-[#f8f9fa] text-neutral-800' : 'bg-[#050505] text-neutral-300'
    }`}>
      {/* Subtle Horizontal Scroll Progress Bar at the very top of screen */}
      <ScrollProgressBar activeModalId={selectedArticleId ? 'blog-modal-content' : null} />

      {/* Halftone / Dot Matrix Background Overlay */}
      <div className={`fixed inset-0 pointer-events-none z-0 ${
        theme === 'light' ? 'opacity-30' : 'opacity-100'
      }`}>
        <div className="absolute inset-0 bg-dot-matrix opacity-70" />
        {/* Subtle radial vignette */}
        <div className={`absolute inset-0 ${
          theme === 'light'
            ? 'bg-[radial-gradient(circle_at_center,transparent_0%,rgba(240,242,245,0.6)_100%)]'
            : 'bg-[radial-gradient(circle_at_center,transparent_0%,rgba(5,5,5,0.7)_100%)]'
        }`} />
      </div>

      {/* Main Content Column */}
      <main className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-20">
        
        {/* 1. Header / Hero Profile Zone */}
        <section className="max-w-2xl mx-auto flex flex-col items-center text-center mb-14">
          {/* Avatar with click to view modal */}
          <div className="mb-6">
            <CalamburAvatar size="md" onZoom={() => setIsAvatarOpen(true)} />
          </div>

          {/* "FIND ME AT" Subtitle */}
          <h2 className="text-[11px] font-mono tracking-[0.25em] text-neutral-500 dark:text-neutral-400 uppercase select-none mb-1">
            {t.findMeAt}
          </h2>

          {/* Social Links Row (Only 3 links: GitHub, X, Substack) */}
          <SocialLinks />
        </section>

        {/* 2. ABOUT ME Section */}
        <section className="max-w-2xl mx-auto mb-14">
          <h2 className="text-xs font-mono tracking-widest text-neutral-500 dark:text-neutral-400 uppercase mb-4">
            {t.aboutMeTitle}
          </h2>
          <div className="space-y-3.5 text-xs sm:text-[13px] leading-relaxed text-neutral-700 dark:text-neutral-400 font-mono">
            {t.aboutMeParagraphs.map((paragraph, idx) => (
              <p key={idx} className="hover:text-neutral-900 dark:hover:text-neutral-300 transition-colors">
                {paragraph}
              </p>
            ))}
          </div>
        </section>

        {/* 3. PROJECTS Section */}
        <div className="max-w-2xl mx-auto">
          <Projects
            t={t}
            onSelectProject={(id) => setSelectedProject(id)}
          />
        </div>

        {/* 4. ACTIVITY Section (EXPANDED TO FULL SCREEN WIDTH) */}
        <div className="w-full my-12">
          <Activity t={t} />
        </div>

        {/* 5. SKILLS & TOOLS Section */}
        <div className="max-w-2xl mx-auto">
          <Skills t={t} />
        </div>

        {/* 6. WORK -> OPEN COMMISSIONS Section */}
        <div className="max-w-2xl mx-auto">
          <Work
            t={t}
            onOpenPreview={(id) => setSelectedProject(id)}
          />
        </div>

        {/* 7. BLOG Section */}
        <div className="max-w-2xl mx-auto">
          <Blog
            t={t}
            onOpenArticle={(id) => setSelectedArticleId(id)}
          />
        </div>

        {/* 8. Footer Area */}
        <footer className="pt-10 border-t border-neutral-200 dark:border-neutral-900/80 flex flex-col items-center text-center space-y-6">
          {/* Join Newsletter (Substack) */}
          <Newsletter t={t} />

          {/* Call to action */}
          <p className="text-xs font-mono text-neutral-600 dark:text-neutral-400">
            {t.footerIdea}{' '}
            <button
              onClick={() => setIsContactOpen(true)}
              className="text-neutral-900 dark:text-neutral-200 underline underline-offset-4 decoration-neutral-400 dark:decoration-neutral-600 hover:decoration-black dark:hover:decoration-white hover:text-black dark:hover:text-white transition-colors"
            >
              {t.letsTalk}.
            </button>
          </p>

          {/* Controls Bar: Theme & Language */}
          <div className="flex items-center gap-4 py-1.5 px-3 rounded-full bg-white dark:bg-neutral-950/80 border border-neutral-200 dark:border-neutral-800/80 shadow-md backdrop-blur-md">
            {/* Theme Toggle */}
            <div className="flex items-center gap-1 pr-3 border-r border-neutral-200 dark:border-neutral-800">
              <button
                type="button"
                onClick={() => setTheme('light')}
                className={`p-1.5 rounded-full transition-colors ${
                  theme === 'light'
                    ? 'text-neutral-900 bg-neutral-200 shadow-sm'
                    : 'text-neutral-400 hover:text-neutral-700 dark:text-neutral-500 dark:hover:text-neutral-300'
                }`}
                title="Light mode"
                aria-label="Light mode"
              >
                <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 stroke-current fill-none stroke-2">
                  <circle cx="12" cy="12" r="5" />
                  <line x1="12" y1="1" x2="12" y2="3" />
                  <line x1="12" y1="21" x2="12" y2="23" />
                  <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" />
                  <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
                  <line x1="1" y1="12" x2="3" y2="12" />
                  <line x1="21" y1="12" x2="23" y2="12" />
                  <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" />
                  <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
                </svg>
              </button>
              <button
                type="button"
                onClick={() => setTheme('dark')}
                className={`p-1.5 rounded-full transition-colors ${
                  theme === 'dark'
                    ? 'text-white bg-neutral-800 shadow-sm'
                    : 'text-neutral-400 hover:text-neutral-700 dark:text-neutral-500 dark:hover:text-neutral-300'
                }`}
                title="Dark mode"
                aria-label="Dark mode"
              >
                <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 stroke-current fill-none stroke-2">
                  <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
                </svg>
              </button>
              <button
                type="button"
                onClick={() => setTheme('system')}
                className={`p-1.5 rounded-full transition-colors ${
                  theme === 'system'
                    ? 'text-neutral-900 bg-neutral-200 dark:text-white dark:bg-neutral-800 shadow-sm'
                    : 'text-neutral-400 hover:text-neutral-700 dark:text-neutral-500 dark:hover:text-neutral-300'
                }`}
                title="System theme"
                aria-label="System theme"
              >
                <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 stroke-current fill-none stroke-2">
                  <rect x="2" y="3" width="20" height="14" rx="2" ry="2" />
                  <line x1="8" y1="21" x2="16" y2="21" />
                  <line x1="12" y1="17" x2="12" y2="21" />
                </svg>
              </button>
            </div>

            {/* Language Selector: ONLY EN and ES */}
            <div className="flex items-center gap-1 text-[11px] font-mono">
              {(['en', 'es'] as Language[]).map((l) => (
                <button
                  key={l}
                  type="button"
                  onClick={() => setLang(l)}
                  className={`px-2 py-0.5 rounded uppercase transition-colors ${
                    lang === l
                      ? 'text-neutral-900 bg-neutral-200 dark:text-white font-semibold dark:bg-neutral-800 shadow-sm'
                      : 'text-neutral-400 hover:text-neutral-700 dark:text-neutral-500 dark:hover:text-neutral-300'
                  }`}
                >
                  {l}
                </button>
              ))}
            </div>
          </div>

          {/* Copyright */}
          <div className="text-[11px] font-mono text-neutral-500 dark:text-neutral-600">
            2026 © Calambur
          </div>
        </footer>
      </main>

      {/* Interactive Modals */}
      <ContactModal
        isOpen={isContactOpen}
        onClose={() => setIsContactOpen(false)}
        t={t}
      />

      <ProjectModal
        projectId={selectedProject}
        onClose={() => setSelectedProject(null)}
        t={t}
      />

      <BlogModal
        articleId={selectedArticleId}
        onClose={() => setSelectedArticleId(null)}
        t={t}
      />

      <AvatarModal
        isOpen={isAvatarOpen}
        onClose={() => setIsAvatarOpen(false)}
      />
    </div>
  );
}
