/**
 * Calculates estimated reading time based on total word count and average words per minute.
 * Default reading speed is 200 words per minute (standard WPM for technical/editorial articles).
 */
export function calculateReadingTime(text: string | string[], wordsPerMinute = 200): number {
  const combined = Array.isArray(text) ? text.join(' ') : text;
  if (!combined || !combined.trim()) return 1;
  
  // Clean punctuation and count words
  const words = combined.trim().split(/\s+/).filter(Boolean).length;
  const minutes = Math.ceil(words / wordsPerMinute);
  return Math.max(1, minutes);
}

export function countWords(text: string | string[]): number {
  const combined = Array.isArray(text) ? text.join(' ') : text;
  if (!combined || !combined.trim()) return 0;
  return combined.trim().split(/\s+/).filter(Boolean).length;
}

/**
 * Full narrative, technical specs, and in-depth content data for blog posts,
 * used to calculate precise reading times and render rich preview/modal content.
 */
export const blogArticlesContent: Record<number, {
  targetMinutes: number;
  specs: { label: string; val: string }[];
  paragraphs: {
    en: string[];
    es: string[];
  };
}> = {
  1: {
    targetMinutes: 4,
    specs: [
      { label: 'Camera', val: 'Leica Q2 Monochrom 28mm f/1.7' },
      { label: 'Exposure', val: '1/125s at f/2.0, ISO 400' },
      { label: 'Hardware', val: 'MacBook Pro M3 Max (Space Black)' },
      { label: 'Desk Essentials', val: 'Matte black Yerba Mate cup & bombilla' },
    ],
    paragraphs: {
      en: [
        'A deep dive into daily ergonomics for long coding sessions. Balancing deep dark software themes with warm natural desk materials to minimize optical fatigue across 10-hour focus blocks.',
        'Terminal typography tuned with JetBrains Mono at 13.5px, 1.45 line height, and zero unnecessary dock clutter or telemetry distractions. Every pixel in the workspace serves a purpose, preventing cognitive overload.',
        'The physical layout is deliberately constrained: only three items remain on the desk surface at any given moment. Cables are channeled through under-desk aluminum raceways, eliminating visual friction and mental context switches.',
        'Lighting is calibrated to 3200K diffuse bounce off the rear wall, matching the exact color temperature of the terminal background to prevent pupil contraction during nighttime engineering sessions.',
        'Hydration and ritual: the matte black thermos and Argentine mate ritual anchor the day into natural pomodoro-style pauses, providing steady sustained focus without caffeine spikes.',
        'Thermal management and acoustics: passive laptop stands maintain airflow, ensuring silent fan operation even when compiling heavy Rust security binaries or running local LLM quantizations.'
      ],
      es: [
        'Un análisis profundo sobre ergonomía diaria para largas sesiones de código. Equilibrando temas de software oscuros con materiales de escritorio naturales para minimizar la fatiga visual en bloques de enfoque de 10 horas.',
        'Tipografía de terminal calibrada con JetBrains Mono a 13.5px, 1.45 de interlineado y cero distracciones o barras de estado innecesarias. Cada píxel en el espacio de trabajo cumple una función clara.',
        'La distribución física está deliberadamente limitada: solo tres objetos permanecen en la superficie del escritorio en cualquier momento. Los cables van canalizados por bandejas de aluminio ocultas, eliminando fricción visual.',
        'La iluminación está ajustada a un rebote difuso de 3200K contra la pared posterior, igualando la temperatura de color del fondo de la terminal para evitar contracción pupilar en sesiones nocturnas.',
        'Ritual de mate: el termo y mate negro mate estructuran las pausas naturales de concentración, aportando energía sostenida sin picos bruscos de cafeína.',
        'Gestión térmica y acústica: un soporte elevado de aluminio maximiza el flujo de aire, manteniendo el equipo completamente silencioso al compilar binarios de ciberseguridad o ejecutar modelos locales.'
      ]
    }
  },
  2: {
    targetMinutes: 5,
    specs: [
      { label: 'Display', val: 'LG 38WN95C Curved Ultrawide (3840x1600)' },
      { label: 'Lightbar', val: 'BenQ ScreenBar Halo with 2700K backlight' },
      { label: 'Desk Shelf', val: 'Solid American Walnut with CNC aluminum legs' },
      { label: 'Audio', val: 'Sennheiser HD 600 + Schiit Magni DAC' },
    ],
    paragraphs: {
      en: [
        'Eliminating window switching latency through horizontal division: left 60% dedicated to the active code buffer and architectural notes, right 40% reserved for live headless browser previews and test runners.',
        'Ambient backlighting matched to screen luminance to relieve eye strain during late night development sprints. The curved 2300R radius provides uniform focal distance from edge to center, preserving peripheral awareness without neck strain.',
        'Acoustics play an understated role: open-back planar headphones deliver a neutral soundstage that anchors focus without creating isolation fatigue or physical ear clamping over hours of system design.',
        'Window management is fully keyboard-driven via custom tiling scripts: jumping between terminal multiplexer panes and automated threat telemetry streams occurs in single keystrokes.',
        'Color grading: a bespoke low-contrast Kanagawa/Obsidian palette is deployed across all IDE buffers, removing glaring pure whites in favor of muted sage greens, cyber cyans, and warm charcoal grays.',
        'The desk shelf lifts the display to exact eye level, keeping the cervical spine aligned and leaving the lower desk shelf completely open for notebooks and security threat modeling sketches.'
      ],
      es: [
        'Eliminación de la latencia al cambiar de ventana mediante división horizontal: 60% izquierdo dedicado al buffer de código activo y notas, 40% derecho reservado para vista previa en vivo y suites de prueba.',
        'Retroiluminación ambiental sincronizada con la luminancia de la pantalla para aliviar la tensión ocular durante sprints nocturnos. El radio curvo 2300R mantiene una distancia focal uniforme de borde a centro sin sobrecargar el cuello.',
        'La acústica desempeña un papel clave: auriculares abiertos proporcionan un escenario sonoro neutro que ancla la concentración sin generar fatiga de aislamiento durante horas de diseño de sistemas.',
        'Gestión de ventanas puramente por teclado mediante atajos personalizados: saltar entre paneles de terminal y streams de telemetría de amenazas ocurre en milisegundos.',
        'Paleta de color adaptada: esquema de bajo contraste inspirado en tonos oscuros y Kanagawa, eliminando blancos estridentes y priorizando tonos carbón, verde salvia y cyan.',
        'El elevador de nogal macizo posiciona la pantalla a la altura exacta de la mirada, liberando espacio inferior para notas manuscritas y diagramas de vectores de ataque.'
      ]
    }
  },
  3: {
    targetMinutes: 3,
    specs: [
      { label: 'Board', val: 'Keycult No. 1/65 (Black/Brass)' },
      { label: 'Switches', val: 'Gateron Oil Kings (Krytox 205g0 lubed)' },
      { label: 'Keycaps', val: 'GMK Stealth + Dark Charcoal mods' },
      { label: 'Stabilizers', val: 'Durock V2 screw-in (Holee mod)' },
    ],
    paragraphs: {
      en: [
        'Acoustics and tactile feedback calibration for high typing velocity. Measuring force displacement curves for sustained typing endurance without joint fatigue across daily 8,000-line coding sprints.',
        'Custom QMK/VIA keymap with dedicated layers for Vim navigation, tmux window switching, and window management shortcuts mapped directly under the home row via tap-dance and mod-tap configurations.',
        'Gasket-mount leaf springs paired with a polished solid brass weight dampens high-frequency resonance, transforming sharp key clacks into a muted, deep baritone acoustic profile that blends into the background of a quiet studio.',
        'PBT double-shot keycaps in stealth charcoal finish provide a textured, non-slippery contact surface that maintains grip through demanding incident response drills.'
      ],
      es: [
        'Calibración acústica y táctil para alta velocidad de digitación. Medición de curvas de fuerza para una resistencia sostenida sin fatiga en articulaciones durante largas jornadas de programación.',
        'Mapa de teclas custom con QMK/VIA con capas dedicadas para navegación en Vim, cambio de paneles en tmux y atajos de ventanas bajo la fila base (home row) con mod-tap.',
        'Montaje gasket con placa elástica y peso de latón sólido pulido que atenúa resonancias agudas, transformando el sonido en un perfil acústico grave y profundo que no satura el estudio.',
        'Keycaps de textura mate en tono grafito sigiloso que garantizan agarre óptimo durante ejercicios intensos de respuesta ante incidentes.'
      ]
    }
  }
};

/**
 * Returns complete reading stats for a given article ID and language.
 */
export function getArticleReadingStats(articleId: number, lang: 'en' | 'es' = 'en') {
  const article = blogArticlesContent[articleId];
  if (!article) return { minutes: 3, words: 600, targetMinutes: 3 };

  const paras = article.paragraphs[lang] || article.paragraphs.en;
  const words = countWords(paras);
  const calculated = calculateReadingTime(paras, 160); // 160 wpm for dense technical literature
  const minutes = Math.max(article.targetMinutes, calculated);

  return {
    minutes,
    words,
    targetMinutes: article.targetMinutes,
  };
}
