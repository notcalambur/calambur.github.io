import React, { useState } from 'react';

interface AvatarProps {
  size?: 'sm' | 'md' | 'lg';
  onZoom?: () => void;
}

export const CalamburAvatar: React.FC<AvatarProps> = ({ size = 'md', onZoom }) => {
  const [imgError, setImgError] = useState(false);

  const sizeClasses = {
    sm: 'w-16 h-16',
    md: 'w-28 h-28 md:w-32 md:h-32',
    lg: 'w-48 h-48 md:w-56 md:h-56',
  }[size];

  // The exact user-provided profile photo MvkgKFcj_400x400.jpg
  const avatarSrc = imgError 
    ? "/avatar.jpg"
    : "/MvkgKFcj_400x400.jpg";

  return (
    <div className="relative group inline-block">
      {/* Outer ambient glow */}
      <div 
        className="absolute -inset-1.5 rounded-full blur-md transition-all duration-700 opacity-30 dark:opacity-40 group-hover:opacity-70 dark:group-hover:opacity-80 bg-gradient-to-r from-red-600/40 via-amber-500/30 to-neutral-700 pointer-events-none"
      />

      {/* Main Avatar Container */}
      <div
        onClick={onZoom}
        className={`${sizeClasses} relative rounded-full overflow-hidden border-2 border-neutral-300 dark:border-neutral-700/80 group-hover:border-neutral-900 dark:group-hover:border-neutral-400 bg-neutral-900 shadow-xl cursor-pointer transform transition-all duration-300 group-hover:scale-105 active:scale-95`}
        title="Calambur - Profile Photo (Click to inspect)"
      >
        <img
          src={avatarSrc}
          alt="Calambur"
          onError={() => setImgError(true)}
          className="w-full h-full object-cover select-none transition-transform duration-500 group-hover:scale-110"
        />

        {/* Subtle glass reflection overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-white/[0.1] via-transparent to-black/30 pointer-events-none" />
      </div>

      {/* Subtle indicator hint */}
      <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 z-10 pointer-events-none">
        <span className="text-[9px] font-mono tracking-wider px-2 py-0.5 rounded-full bg-white dark:bg-neutral-900 text-neutral-800 dark:text-neutral-300 border border-neutral-200 dark:border-neutral-700 whitespace-nowrap shadow-md">
          VIEW
        </span>
      </div>
    </div>
  );
};
