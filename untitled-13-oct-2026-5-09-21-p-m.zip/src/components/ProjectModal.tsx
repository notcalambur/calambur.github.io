import React from 'react';
import { Translations } from '../data/translations';

interface ProjectModalProps {
  projectId: string | null;
  onClose: () => void;
  t: Translations;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({ projectId, onClose, t }) => {
  if (!projectId) return null;

  const getProjectDetails = () => {
    switch (projectId) {
      case 'sentinel-bench':
        return {
          title: t.projects.sentinelBench.title,
          subtitle: t.projects.sentinelBench.subtitle,
          description: t.projects.sentinelBench.description,
          tags: ['Python 3.14', 'Astro', 'CISA KEV', 'NVD / EPSS', 'Telegram', 'Threat Intel'],
          favicon: '/sentinel-favicon.svg',
          metrics: [
            { label: 'Noise Filtered', val: '96% of NVD' },
            { label: 'Prioritization', val: 'CISA KEV + EPSS' },
            { label: 'Tests Suite', val: '22 Python + tsc' }
          ],
          features: [
            'Personal Cyber Threat Intelligence lab normalizing public CVE noise',
            'Automated vendor advisory remediation extraction across 30+ major security vendors',
            'Direct Telegram dispatch alerts for critical actively-exploited vulnerabilities',
            'Modern industrial HUD dashboard with live attack map visualization'
          ],
          links: [
            { label: 'Launch Sentinel-Bench', url: 'https://sentinel-bench.vercel.app/' },
            { label: 'GitHub Repository', url: 'https://github.com/notcalambur/sentinel-bench' }
          ]
        };
      case 'vibe-checker':
      default:
        return {
          title: t.projects.vibeChecker.title,
          subtitle: t.projects.vibeChecker.subtitle,
          description: t.projects.vibeChecker.description,
          tags: ['TypeScript', 'Next.js', 'AI Vibe Coding', 'Vulnerability Scanner', 'Solana'],
          favicon: '/vibecode-favicon.svg',
          metrics: [
            { label: 'Target Tools', val: 'Cursor, Lovable, Bolt' },
            { label: 'AI Remediation', val: 'Ready-to-use Prompts' },
            { label: 'Scan Speed', val: '< 2.5s' }
          ],
          features: [
            'Free automated vulnerability scanner built specifically for vibe-coded applications',
            'Finds exposed debug endpoints, unsafe CORS headers, and hardcoded API tokens',
            'Generates tailor-made AI fix prompts to paste directly into your AI coding assistant',
            'Integrates with Sentinel-Bench public intelligence API to cross-reference known CVEs'
          ],
          links: [
            { label: 'Launch VibeChecker', url: 'https://vibecode-checker.vercel.app/' },
            { label: 'GitHub Repository', url: 'https://github.com/notcalambur/vibecode-scanner' }
          ]
        };
    }
  };

  const details = getProjectDetails();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div 
        className="relative w-full max-w-xl max-h-[90vh] overflow-y-auto p-6 sm:p-8 bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-3xl shadow-2xl space-y-6"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 right-5 text-neutral-400 hover:text-neutral-900 dark:hover:text-white p-1.5 rounded-xl hover:bg-neutral-100 dark:hover:bg-neutral-900 transition-colors"
          aria-label="Close modal"
        >
          <svg viewBox="0 0 24 24" className="w-5 h-5 stroke-current fill-none stroke-2">
            <line x1="18" y1="6" x2="6" y2="18" />
            <line x1="6" y1="6" x2="18" y2="18" />
          </svg>
        </button>

        {/* Header with Project Favicon */}
        <div className="flex items-start gap-4 pr-8">
          <div className="w-12 h-12 rounded-2xl border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900 flex items-center justify-center p-2 shrink-0 shadow-sm">
            <img src={details.favicon} alt={details.title} className="w-8 h-8 object-contain" />
          </div>
          <div>
            <h3 className="font-mono text-xl sm:text-2xl font-bold text-neutral-900 dark:text-white">
              {details.title}
            </h3>
            <p className="text-xs font-mono text-cyan-600 dark:text-cyan-400 font-medium">
              {details.subtitle}
            </p>
          </div>
        </div>

        {/* Description */}
        <p className="text-sm text-neutral-700 dark:text-neutral-300 font-sans leading-relaxed">
          {details.description}
        </p>

        {/* Tech Stack Tags */}
        <div className="flex flex-wrap gap-1.5">
          {details.tags.map((tag) => (
            <span
              key={tag}
              className="text-[11px] font-mono px-2.5 py-1 rounded-lg bg-neutral-100 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 text-neutral-700 dark:text-neutral-300"
            >
              {tag}
            </span>
          ))}
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-3 gap-3 p-4 rounded-2xl bg-neutral-50 dark:bg-neutral-900/60 border border-neutral-200 dark:border-neutral-800/80">
          {details.metrics.map((m, idx) => (
            <div key={idx} className="text-center">
              <span className="block text-xs font-mono font-bold text-neutral-900 dark:text-white">{m.val}</span>
              <span className="block text-[10px] font-mono text-neutral-500 uppercase">{m.label}</span>
            </div>
          ))}
        </div>

        {/* Features list */}
        <div className="space-y-2">
          <h4 className="text-xs font-mono tracking-wider text-neutral-500 dark:text-neutral-400 uppercase">
            Architectural Highlights
          </h4>
          <ul className="space-y-2 text-xs font-sans text-neutral-600 dark:text-neutral-300">
            {details.features.map((feat, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="text-emerald-500 font-bold shrink-0">✓</span>
                <span>{feat}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Action Links */}
        <div className="flex flex-wrap items-center gap-3 pt-3 border-t border-neutral-200 dark:border-neutral-800">
          {details.links.map((link, idx) => (
            <a
              key={idx}
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              className={`inline-flex items-center gap-2 text-xs font-mono px-4 py-2.5 rounded-xl transition-all shadow-sm ${
                idx === 0
                  ? 'bg-neutral-900 text-white dark:bg-white dark:text-black hover:bg-neutral-800 dark:hover:bg-neutral-200 font-medium'
                  : 'bg-neutral-100 dark:bg-neutral-900 text-neutral-700 dark:text-neutral-300 border border-neutral-200 dark:border-neutral-800 hover:border-neutral-400'
              }`}
            >
              <span>{link.label}</span>
              <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 stroke-current fill-none stroke-2">
                <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                <polyline points="15 3 21 3 21 9" />
                <line x1="10" y1="14" x2="21" y2="3" />
              </svg>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
};
