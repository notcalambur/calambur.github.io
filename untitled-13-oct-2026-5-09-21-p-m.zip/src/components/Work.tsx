import React, { useState } from 'react';
import { Translations } from '../data/translations';

interface WorkProps {
  t: Translations;
  onOpenPreview?: (workId: string) => void;
}

export const Work: React.FC<WorkProps> = ({ t }) => {
  const [copied, setCopied] = useState(false);

  const handleCopyEmail = (e: React.MouseEvent) => {
    e.preventDefault();
    navigator.clipboard.writeText(t.openCommissions.email);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section className="mb-14">
      {/* Section Header */}
      <div className="flex items-center gap-2 mb-4">
        <h2 className="text-xs font-mono tracking-widest text-neutral-500 dark:text-neutral-400 uppercase">
          {t.commissionsTitle}
        </h2>
        <span className="inline-flex items-center gap-1.5 text-[10px] font-mono tracking-wider text-emerald-600 dark:text-emerald-400 uppercase bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800/80 px-2 py-0.5 rounded-full">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
          {t.openCommissions.badge}
        </span>
      </div>

      {/* Main Open Commissions Card */}
      <div className="group relative rounded-3xl border border-neutral-200 dark:border-neutral-800/80 bg-white dark:bg-neutral-950/70 p-6 sm:p-8 hover:border-neutral-300 dark:hover:border-neutral-700 shadow-sm hover:shadow-xl transition-all duration-300 backdrop-blur-sm overflow-hidden">
        {/* Subtle Ambient Background Gradient Glow */}
        <div className="absolute -right-20 -bottom-20 w-72 h-72 bg-emerald-500/5 dark:bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -left-20 -top-20 w-72 h-72 bg-cyan-500/5 dark:bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          {/* Left Side: Overview & Services */}
          <div className="space-y-4 max-w-xl">
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <span className="text-xl">💼</span>
                <h3 className="font-mono text-xl sm:text-2xl font-bold text-neutral-900 dark:text-white tracking-tight">
                  {t.openCommissions.title}
                </h3>
              </div>
              <p className="text-xs sm:text-sm text-neutral-600 dark:text-neutral-400 font-sans leading-relaxed">
                {t.openCommissions.description}
              </p>
            </div>

            {/* Services Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
              {t.openCommissions.services.map((service, idx) => (
                <div
                  key={idx}
                  className="flex items-center gap-2 text-xs font-mono text-neutral-700 dark:text-neutral-300 bg-neutral-50 dark:bg-neutral-900/80 border border-neutral-200/80 dark:border-neutral-800/80 px-3 py-2 rounded-xl"
                >
                  <span className="text-emerald-500 font-bold">✓</span>
                  <span>{service}</span>
                </div>
              ))}
            </div>

            {/* Email Contact CTA Bar */}
            <div className="pt-2 flex flex-wrap items-center gap-3">
              {/* Mailto Button */}
              <a
                href={`mailto:${t.openCommissions.email}?subject=Commission%20Inquiry%20-%20Calambur`}
                className="inline-flex items-center gap-2 text-xs font-mono font-medium text-white bg-neutral-900 dark:bg-white dark:text-black hover:bg-neutral-800 dark:hover:bg-neutral-200 px-4 py-2.5 rounded-xl transition-all shadow-md active:scale-95"
              >
                <svg viewBox="0 0 24 24" className="w-4 h-4 stroke-current fill-none stroke-2">
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                  <polyline points="22,6 12,13 2,6" />
                </svg>
                <span>{t.openCommissions.button}</span>
              </a>

              {/* Copy Email Button */}
              <button
                type="button"
                onClick={handleCopyEmail}
                className="inline-flex items-center gap-2 text-xs font-mono text-neutral-700 dark:text-neutral-300 bg-neutral-100 dark:bg-neutral-900 hover:bg-neutral-200 dark:hover:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 px-3.5 py-2.5 rounded-xl transition-all active:scale-95"
                title="Copy email to clipboard"
              >
                {copied ? (
                  <>
                    <svg viewBox="0 0 24 24" className="w-4 h-4 stroke-emerald-500 fill-none stroke-2">
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                    <span className="text-emerald-500 font-semibold">{t.openCommissions.copied}</span>
                  </>
                ) : (
                  <>
                    <svg viewBox="0 0 24 24" className="w-4 h-4 stroke-current fill-none stroke-2">
                      <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
                      <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
                    </svg>
                    <span>{t.openCommissions.copyButton}</span>
                  </>
                )}
              </button>

              {/* Direct email badge */}
              <code className="text-[11px] font-mono text-neutral-500 dark:text-neutral-400 bg-neutral-100 dark:bg-neutral-900/60 px-2.5 py-1.5 rounded-lg border border-neutral-200 dark:border-neutral-800">
                {t.openCommissions.email}
              </code>
            </div>
          </div>

          {/* Right Side: Cyber Shield Radar Graphic Emblem */}
          <div className="shrink-0 flex items-center justify-center pt-2 md:pt-0">
            <div className="w-28 h-28 sm:w-36 sm:h-36 rounded-2xl border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900/60 flex items-center justify-center relative p-4 group-hover:border-emerald-500/50 transition-colors shadow-inner">
              <svg viewBox="0 0 100 100" className="w-full h-full text-emerald-500/80">
                {/* Radar grid circles */}
                <circle cx="50" cy="50" r="42" fill="none" stroke="currentColor" strokeWidth="1" strokeDasharray="3 3" opacity="0.3" />
                <circle cx="50" cy="50" r="28" fill="none" stroke="currentColor" strokeWidth="1" opacity="0.4" />
                <circle cx="50" cy="50" r="14" fill="none" stroke="currentColor" strokeWidth="1.2" opacity="0.6" />
                {/* Crosshairs */}
                <line x1="50" y1="6" x2="50" y2="94" stroke="currentColor" strokeWidth="1" opacity="0.3" />
                <line x1="6" y1="50" x2="94" y2="50" stroke="currentColor" strokeWidth="1" opacity="0.3" />
                {/* Center cyber shield icon */}
                <path
                  d="M50 24 L72 32 V54 C72 68 62 76 50 82 C38 76 28 68 28 54 V32 Z"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.5"
                  strokeLinejoin="round"
                />
                <path
                  d="M42 50 L48 56 L58 44"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
