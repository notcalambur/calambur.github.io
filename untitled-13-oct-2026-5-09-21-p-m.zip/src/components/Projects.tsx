import React, { useState } from 'react';
import { Translations } from '../data/translations';

interface ProjectsProps {
  t: Translations;
  onSelectProject: (projectId: string) => void;
}

export const Projects: React.FC<ProjectsProps> = ({ t, onSelectProject }) => {
  const [hoveredCard, setHoveredCard] = useState<string | null>(null);

  const projects = [
    {
      id: 'sentinel-bench',
      title: t.projects.sentinelBench.title,
      subtitle: t.projects.sentinelBench.subtitle,
      description: t.projects.sentinelBench.description,
      tags: ['CISA KEV', 'Threat Intel', 'Astro', 'NVD / EPSS', 'Telegram'],
      url: 'https://sentinel-bench.vercel.app/',
      repoUrl: 'https://github.com/notcalambur/sentinel-bench',
      faviconSrc: '/sentinel-favicon.svg',
      accentColor: 'cyan',
    },
    {
      id: 'vibe-checker',
      title: t.projects.vibeChecker.title,
      subtitle: t.projects.vibeChecker.subtitle,
      description: t.projects.vibeChecker.description,
      tags: ['AI Security', 'Vibe Coding', 'Vulnerability Scanner', 'Next.js', 'Solana'],
      url: 'https://vibecode-checker.vercel.app/',
      repoUrl: 'https://github.com/notcalambur/vibecode-scanner',
      faviconSrc: '/vibecode-favicon.svg',
      accentColor: 'emerald',
    },
  ];

  return (
    <section className="mb-14">
      {/* Section Header */}
      <div className="flex items-center gap-2 mb-4">
        <h2 className="text-xs font-mono tracking-widest text-neutral-500 dark:text-neutral-400 uppercase">
          {t.projectsTitle}
        </h2>
        <span className="inline-flex items-center gap-1.5 text-[10px] font-mono tracking-wider text-neutral-500 uppercase">
          <svg viewBox="0 0 24 24" className="w-3 h-3 stroke-current fill-none stroke-2">
            <path d="M4.9 19.1C1 15.2 1 8.8 4.9 4.9M7.8 16.2c-2.3-2.3-2.3-6.1 0-8.5M12 12h.01" />
          </svg>
          {t.currentlyBuilding}
        </span>
      </div>

      {/* Projects Grid / Stack */}
      <div className="space-y-4">
        {projects.map((proj) => (
          <div
            key={proj.id}
            onMouseEnter={() => setHoveredCard(proj.id)}
            onMouseLeave={() => setHoveredCard(null)}
            className="group relative flex flex-col sm:flex-row sm:items-center justify-between p-5 md:p-6 rounded-2xl border border-neutral-200 dark:border-neutral-800/80 bg-white dark:bg-neutral-950/70 hover:border-neutral-300 dark:hover:border-neutral-700 shadow-sm hover:shadow-xl transition-all duration-200 backdrop-blur-sm overflow-hidden gap-4"
          >
            {/* Left Accent Bar on Hover */}
            <div
              className={`absolute left-0 top-0 bottom-0 w-1 transition-opacity duration-200 ${
                proj.accentColor === 'cyan' ? 'bg-cyan-500' : 'bg-emerald-500'
              } ${hoveredCard === proj.id ? 'opacity-100' : 'opacity-0'}`}
            />

            {/* Left/Middle Content */}
            <div className="flex items-start gap-4 flex-1">
              {/* Real ICO / Favicon Display with crisp border badge */}
              <div className="shrink-0 pt-0.5">
                <div className={`w-14 h-14 rounded-2xl border flex items-center justify-center shadow-md p-2 transition-transform duration-200 group-hover:scale-105 ${
                  proj.accentColor === 'cyan' 
                    ? 'border-cyan-200 dark:border-cyan-900/60 bg-cyan-50/50 dark:bg-[#0b0d12]' 
                    : 'border-emerald-200 dark:border-emerald-900/60 bg-emerald-50/50 dark:bg-[#0b0f0b]'
                }`}>
                  <img
                    src={proj.faviconSrc}
                    alt={`${proj.title} favicon`}
                    className="w-10 h-10 object-contain drop-shadow"
                  />
                </div>
              </div>

              <div className="space-y-1.5 flex-1 pr-2">
                <div className="flex items-center gap-2.5 flex-wrap">
                  <h3 className="font-mono text-base md:text-lg font-bold text-neutral-900 dark:text-white tracking-wide group-hover:text-cyan-600 dark:group-hover:text-cyan-400 transition-colors">
                    {proj.title}
                  </h3>
                  <a
                    href={proj.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => e.stopPropagation()}
                    className="inline-flex items-center gap-1 text-[11px] font-mono text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white px-2 py-0.5 rounded border border-neutral-200 dark:border-neutral-800 hover:border-neutral-400 transition-colors bg-neutral-50 dark:bg-neutral-900/60"
                  >
                    <span>visit site</span>
                    <svg viewBox="0 0 24 24" className="w-3 h-3 stroke-current fill-none stroke-2">
                      <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                      <polyline points="15 3 21 3 21 9" />
                      <line x1="10" y1="14" x2="21" y2="3" />
                    </svg>
                  </a>
                </div>

                <p className={`text-xs font-mono font-medium ${
                  proj.accentColor === 'cyan' ? 'text-cyan-700 dark:text-cyan-400' : 'text-emerald-700 dark:text-emerald-400'
                }`}>
                  {proj.subtitle}
                </p>

                <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed font-sans line-clamp-2">
                  {proj.description}
                </p>

                {/* Tags */}
                <div className="flex flex-wrap items-center gap-1.5 pt-1.5">
                  {proj.tags.map((tag) => (
                    <span
                      key={tag}
                      className="inline-flex items-center gap-1 text-[10px] font-mono text-neutral-700 dark:text-neutral-400 bg-neutral-100 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 px-2 py-0.5 rounded-md"
                    >
                      <span className="w-1 h-1 rounded-full bg-neutral-400 dark:bg-neutral-600" />
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Quick Action Buttons */}
            <div className="flex sm:flex-col items-center sm:items-end gap-2 shrink-0 pt-2 sm:pt-0">
              <a
                href={proj.url}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto text-center px-3.5 py-1.5 text-xs font-mono font-medium rounded-lg bg-neutral-900 text-white dark:bg-white dark:text-black hover:bg-neutral-800 dark:hover:bg-neutral-200 transition-colors shadow-sm"
              >
                Launch App ↗
              </a>
              <button
                type="button"
                onClick={() => onSelectProject(proj.id)}
                className="w-full sm:w-auto text-center px-3.5 py-1.5 text-xs font-mono text-neutral-700 dark:text-neutral-300 bg-neutral-100 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 hover:border-neutral-400 dark:hover:border-neutral-600 rounded-lg transition-colors"
              >
                Inspect Specs
              </button>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
