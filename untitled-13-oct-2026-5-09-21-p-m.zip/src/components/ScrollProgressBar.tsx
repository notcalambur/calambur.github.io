import React, { useEffect, useState } from 'react';

interface ScrollProgressBarProps {
  /** Optional container element or selector to track if inside a modal */
  activeModalId?: string | null;
}

export const ScrollProgressBar: React.FC<ScrollProgressBarProps> = ({ activeModalId }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    // If a modal is open with a scrollable container, track that container
    if (activeModalId) {
      const modalEl = document.getElementById(activeModalId);
      if (modalEl) {
        const handleModalScroll = () => {
          const { scrollTop, scrollHeight, clientHeight } = modalEl;
          const maxScroll = scrollHeight - clientHeight;
          if (maxScroll <= 0) {
            setProgress(100);
          } else {
            const p = (scrollTop / maxScroll) * 100;
            setProgress(Math.min(100, Math.max(0, p)));
          }
        };

        modalEl.addEventListener('scroll', handleModalScroll, { passive: true });
        handleModalScroll();
        return () => modalEl.removeEventListener('scroll', handleModalScroll);
      }
    }

    // Default: track window / document scroll position
    const handleWindowScroll = () => {
      const doc = document.documentElement;
      const totalScroll = doc.scrollHeight - window.innerHeight;
      if (totalScroll <= 0) {
        setProgress(0);
        return;
      }
      const currentScroll = window.scrollY || doc.scrollTop;
      const p = (currentScroll / totalScroll) * 100;
      setProgress(Math.min(100, Math.max(0, p)));
    };

    window.addEventListener('scroll', handleWindowScroll, { passive: true });
    handleWindowScroll();

    return () => {
      window.removeEventListener('scroll', handleWindowScroll);
    };
  }, [activeModalId]);

  return (
    <div
      className="fixed top-0 left-0 right-0 z-50 h-[2px] bg-neutral-900/40 pointer-events-none backdrop-blur-[1px]"
      role="progressbar"
      aria-label="Reading progress"
      aria-valuenow={Math.round(progress)}
      aria-valuemin={0}
      aria-valuemax={100}
    >
      <div
        className="h-full bg-gradient-to-r from-neutral-600 via-neutral-300 to-white transition-[width] duration-75 ease-out shadow-[0_0_8px_rgba(255,255,255,0.35)]"
        style={{ width: `${progress}%` }}
      />
    </div>
  );
};
