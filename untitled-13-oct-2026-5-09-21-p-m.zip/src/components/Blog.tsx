import React, { useState, useMemo } from 'react';
import { Translations } from '../data/translations';
import { getArticleReadingStats } from '../utils/readingTime';

interface BlogProps {
  t: Translations;
  onOpenArticle: (id: number) => void;
}

export const Blog: React.FC<BlogProps> = ({ t, onOpenArticle }) => {
  const [, setHoveredIdx] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTag, setSelectedTag] = useState<string | null>(null);

  const blogItems = useMemo(() => [
    {
      id: 1,
      title: t.blog.item1.title,
      desc: t.blog.item1.desc,
      date: t.blog.item1.date,
      tags: t.blog.item1.tags || ['workspace', 'minimalism', 'terminal', 'ergonomics'],
      visual: (
        <svg viewBox="0 0 320 220" className="w-full h-full object-cover">
          <defs>
            <radialGradient id="deskGlow1" cx="50%" cy="50%" r="70%">
              <stop offset="0%" stopColor="#1a1c22" />
              <stop offset="60%" stopColor="#0c0d10" />
              <stop offset="100%" stopColor="#050507" />
            </radialGradient>
            <linearGradient id="laptopScreen" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#090d16" />
              <stop offset="100%" stopColor="#030408" />
            </linearGradient>
          </defs>
          <rect width="320" height="220" fill="url(#deskGlow1)" />
          
          {/* Laptop Base & Open Lid */}
          <g transform="translate(40, 45) rotate(-8 100 80)">
            {/* Screen Lid */}
            <rect x="20" y="10" width="120" height="85" rx="4" fill="#18181b" stroke="#27272a" strokeWidth="1.5" />
            <rect x="25" y="14" width="110" height="75" rx="2" fill="url(#laptopScreen)" stroke="#3f3f46" strokeWidth="0.5" />
            {/* Terminal Lines on Screen */}
            <line x1="32" y1="24" x2="65" y2="24" stroke="#10b981" strokeWidth="2" strokeLinecap="round" />
            <line x1="32" y1="32" x2="90" y2="32" stroke="#71717a" strokeWidth="1.5" />
            <line x1="32" y1="38" x2="80" y2="38" stroke="#a1a1aa" strokeWidth="1.5" />
            <line x1="32" y1="44" x2="115" y2="44" stroke="#52525b" strokeWidth="1.5" />
            <line x1="32" y1="50" x2="70" y2="50" stroke="#71717a" strokeWidth="1.5" />
            <line x1="32" y1="56" x2="105" y2="56" stroke="#52525b" strokeWidth="1.5" />
            <line x1="32" y1="64" x2="55" y2="64" stroke="#38bdf8" strokeWidth="1.5" strokeLinecap="round" />
            {/* Keyboard Base */}
            <path d="M 10,95 L 150,95 L 165,135 L -5,135 Z" fill="#121316" stroke="#27272a" strokeWidth="1" />
            <rect x="25" y="100" width="110" height="22" rx="2" fill="#09090b" stroke="#1c1d22" strokeWidth="0.5" />
            <rect x="62" y="124" width="36" height="8" rx="1.5" fill="#18181b" />
          </g>

          {/* Mate Cup & Thermos silhouette on dark desk */}
          <g transform="translate(210, 75)">
            <rect x="30" y="10" width="32" height="78" rx="14" fill="#121316" stroke="#27272a" strokeWidth="1.2" />
            <rect x="38" y="2" width="16" height="10" rx="3" fill="#27272a" stroke="#3f3f46" strokeWidth="0.8" />
            <ellipse cx="14" cy="62" rx="14" ry="17" fill="#18181b" stroke="#27272a" strokeWidth="1" />
            <line x1="16" y1="58" x2="2" y2="34" stroke="#a1a1aa" strokeWidth="1.8" strokeLinecap="round" />
          </g>
        </svg>
      ),
    },
    {
      id: 2,
      title: t.blog.item2.title,
      desc: t.blog.item2.desc,
      date: t.blog.item2.date,
      tags: t.blog.item2.tags || ['ultrawide', 'focus', 'hardware', 'productivity'],
      visual: (
        <svg viewBox="0 0 320 220" className="w-full h-full object-cover">
          <defs>
            <radialGradient id="deskGlow2" cx="50%" cy="30%" r="70%">
              <stop offset="0%" stopColor="#1c1e24" />
              <stop offset="60%" stopColor="#0a0b0d" />
              <stop offset="100%" stopColor="#040406" />
            </radialGradient>
            <linearGradient id="curvedMonitor" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#0a0e17" />
              <stop offset="50%" stopColor="#141c2c" />
              <stop offset="100%" stopColor="#0a0e17" />
            </linearGradient>
          </defs>
          <rect width="320" height="220" fill="url(#deskGlow2)" />

          {/* Minimalist Ultrawide Monitor */}
          <g transform="translate(30, 35)">
            <path
              d="M 5,20 Q 130,12 255,20 L 255,100 Q 130,94 5,100 Z"
              fill="url(#curvedMonitor)"
              stroke="#27272a"
              strokeWidth="1.5"
            />
            {/* Monitor Stand */}
            <path d="M 120,100 L 120,135 L 140,135 L 140,100 Z" fill="#18181b" stroke="#27272a" strokeWidth="1" />
            <rect x="100" y="135" width="60" height="6" rx="2" fill="#27272a" />
            {/* IDE Windows / Code Grid on Screen */}
            <rect x="20" y="28" width="68" height="60" rx="2" fill="#06080d" opacity="0.8" />
            <line x1="28" y1="36" x2="55" y2="36" stroke="#38bdf8" strokeWidth="1.5" strokeLinecap="round" />
            <line x1="28" y1="44" x2="78" y2="44" stroke="#52525b" strokeWidth="1" />
            <line x1="28" y1="50" x2="68" y2="50" stroke="#71717a" strokeWidth="1" />
            <rect x="96" y="28" width="144" height="60" rx="2" fill="#06080d" opacity="0.8" />
            <line x1="104" y1="36" x2="160" y2="36" stroke="#10b981" strokeWidth="1.5" strokeLinecap="round" />
            <line x1="104" y1="44" x2="220" y2="44" stroke="#a1a1aa" strokeWidth="1" />
            <line x1="104" y1="50" x2="190" y2="50" stroke="#71717a" strokeWidth="1" />
            <line x1="104" y1="56" x2="210" y2="56" stroke="#52525b" strokeWidth="1" />
          </g>

          {/* Desk Mat & Peripheral outlines */}
          <g transform="translate(50, 155)">
            <rect x="0" y="5" width="220" height="48" rx="4" fill="#0b0c0e" stroke="#1c1d22" strokeWidth="1" />
            <rect x="35" y="15" width="100" height="28" rx="3" fill="#18181b" stroke="#27272a" strokeWidth="0.8" />
            <rect x="160" y="18" width="18" height="24" rx="7" fill="#18181b" stroke="#27272a" strokeWidth="0.8" />
          </g>
        </svg>
      ),
    },
    {
      id: 3,
      title: t.blog.item3.title,
      desc: t.blog.item3.desc,
      date: t.blog.item3.date,
      tags: t.blog.item3.tags || ['keyboards', 'custom', 'tactile', 'gear'],
      visual: (
        <svg viewBox="0 0 320 220" className="w-full h-full object-cover">
          <defs>
            <radialGradient id="deskGlow3" cx="70%" cy="30%" r="70%">
              <stop offset="0%" stopColor="#1e2025" />
              <stop offset="60%" stopColor="#0b0c0e" />
              <stop offset="100%" stopColor="#040405" />
            </radialGradient>
          </defs>
          <rect width="320" height="220" fill="url(#deskGlow3)" />

          {/* Mechanical Keyboard Angled Macro Grid */}
          <g transform="translate(20, 20) rotate(18 160 110)">
            <rect x="0" y="0" width="280" height="130" rx="8" fill="#121316" stroke="#27272a" strokeWidth="2" />
            <rect x="8" y="8" width="264" height="114" rx="5" fill="#09090b" stroke="#1f2024" strokeWidth="1" />

            {/* Individual Keycaps Rows */}
            {Array.from({ length: 5 }).map((_, row) => (
              <g key={row} transform={`translate(14, ${14 + row * 22})`}>
                {Array.from({ length: 12 }).map((_, col) => {
                  const isAccentKey = (row === 0 && col === 0) || (row === 2 && col === 11);
                  const isSpacebar = row === 4 && col >= 3 && col <= 8;
                  if (row === 4 && col > 3 && col <= 8) return null;
                  const width = isSpacebar ? 115 : 18;
                  return (
                    <rect
                      key={col}
                      x={isSpacebar ? 63 : col * 21}
                      y={0}
                      width={width}
                      height={18}
                      rx={3}
                      fill={isAccentKey ? "#27272a" : "#18181b"}
                      stroke="#3f3f46"
                      strokeWidth="0.8"
                    />
                  );
                })}
              </g>
            ))}
          </g>

          <circle cx="240" cy="50" r="28" fill="#ffffff" opacity="0.03" />
        </svg>
      ),
    },
  ], [t]);

  // Extract all unique tags across items
  const allAvailableTags = useMemo(() => {
    const set = new Set<string>();
    blogItems.forEach(item => {
      item.tags.forEach(tag => set.add(tag));
    });
    return Array.from(set);
  }, [blogItems]);

  // Filter items by search query (title or desc or tags) and selected tag
  const filteredItems = useMemo(() => {
    return blogItems.filter(item => {
      // 1. Tag filter
      if (selectedTag && !item.tags.some(tag => tag.toLowerCase() === selectedTag.toLowerCase())) {
        return false;
      }

      // 2. Query filter
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase().trim();
      const matchTitle = item.title.toLowerCase().includes(q);
      const matchDesc = item.desc.toLowerCase().includes(q);
      const matchTag = item.tags.some(tag => tag.toLowerCase().includes(q));

      return matchTitle || matchDesc || matchTag;
    });
  }, [blogItems, searchQuery, selectedTag]);

  const handleTagClick = (tag: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (selectedTag === tag) {
      setSelectedTag(null);
    } else {
      setSelectedTag(tag);
    }
  };

  const handleClearFilters = () => {
    setSearchQuery('');
    setSelectedTag(null);
  };

  return (
    <section className="mb-14">
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        <div className="flex items-center gap-2">
          <h2 className="text-xs font-mono tracking-widest text-neutral-500 dark:text-neutral-400 uppercase">
            {t.blogTitle}
          </h2>
          <span className="inline-flex items-center gap-1.5 text-[10px] font-mono tracking-wider text-neutral-500 uppercase">
            <svg viewBox="0 0 24 24" className="w-3 h-3 stroke-current fill-none stroke-2">
              <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
              <line x1="16" y1="2" x2="16" y2="6" />
              <line x1="8" y1="2" x2="8" y2="6" />
              <line x1="3" y1="10" x2="21" y2="10" />
            </svg>
            {t.comingSoon}
          </span>
        </div>

        {/* Total Articles Counter */}
        <span className="text-[11px] font-mono text-neutral-400 dark:text-neutral-500">
          {filteredItems.length} / {blogItems.length}
        </span>
      </div>

      {/* SEARCH BAR & TAG FILTER AT TOP OF BLOG SECTION */}
      <div className="mb-6 space-y-3">
        {/* Search input field */}
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-neutral-400">
            <svg viewBox="0 0 24 24" className="w-4 h-4 stroke-current fill-none stroke-2">
              <circle cx="11" cy="11" r="8" />
              <line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t.blog.searchPlaceholder}
            className="w-full pl-10 pr-10 py-2.5 text-xs font-mono rounded-xl bg-white dark:bg-neutral-950/80 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-neutral-100 placeholder-neutral-400 focus:outline-none focus:ring-1 focus:ring-cyan-500 focus:border-cyan-500 shadow-sm transition-all"
          />

          {/* Clear button if search is active */}
          {(searchQuery || selectedTag) && (
            <button
              type="button"
              onClick={handleClearFilters}
              className="absolute inset-y-0 right-0 pr-3 flex items-center text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 transition-colors"
              title={t.blog.clearSearch}
              aria-label={t.blog.clearSearch}
            >
              <svg viewBox="0 0 24 24" className="w-4 h-4 stroke-current fill-none stroke-2">
                <line x1="18" y1="6" x2="6" y2="18" />
                <line x1="6" y1="6" x2="18" y2="18" />
              </svg>
            </button>
          )}
        </div>

        {/* Quick Tag Pills */}
        <div className="flex flex-wrap items-center gap-1.5 text-[11px] font-mono">
          <span className="text-neutral-400 dark:text-neutral-500 text-[10px] uppercase tracking-wider mr-1">
            Tags:
          </span>

          {/* "All" button */}
          <button
            type="button"
            onClick={() => setSelectedTag(null)}
            className={`px-2 py-0.5 rounded-md transition-colors cursor-pointer ${
              selectedTag === null
                ? 'bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-900 font-medium'
                : 'bg-neutral-100 text-neutral-600 dark:bg-neutral-900/80 dark:text-neutral-400 hover:bg-neutral-200 dark:hover:bg-neutral-800'
            }`}
          >
            {t.blog.allFilter}
          </button>

          {allAvailableTags.map((tag) => {
            const isSelected = selectedTag?.toLowerCase() === tag.toLowerCase();
            return (
              <button
                key={tag}
                type="button"
                onClick={() => handleTagClick(tag)}
                className={`px-2 py-0.5 rounded-md transition-colors cursor-pointer ${
                  isSelected
                    ? 'bg-cyan-600 text-white dark:bg-cyan-500 dark:text-neutral-950 font-medium'
                    : 'bg-neutral-100 text-neutral-600 dark:bg-neutral-900/80 dark:text-neutral-400 hover:bg-cyan-50 hover:text-cyan-700 dark:hover:bg-cyan-950/40 dark:hover:text-cyan-300'
                }`}
              >
                #{tag}
              </button>
            );
          })}
        </div>
      </div>

      {/* Empty State when no articles match */}
      {filteredItems.length === 0 ? (
        <div className="p-8 text-center rounded-2xl border border-dashed border-neutral-300 dark:border-neutral-800 bg-white/50 dark:bg-neutral-950/40 space-y-3">
          <div className="w-10 h-10 mx-auto rounded-full bg-neutral-100 dark:bg-neutral-900 flex items-center justify-center text-neutral-400">
            <svg viewBox="0 0 24 24" className="w-5 h-5 stroke-current fill-none stroke-2">
              <circle cx="11" cy="11" r="8" />
              <line x1="21" y1="21" x2="16.65" y2="16.65" />
              <line x1="8" y1="11" x2="14" y2="11" />
            </svg>
          </div>
          <div>
            <h3 className="text-xs font-mono font-semibold text-neutral-900 dark:text-neutral-200">
              {t.blog.noArticlesFound}
            </h3>
            <p className="text-[11px] font-mono text-neutral-500 mt-1 max-w-sm mx-auto">
              {t.blog.noArticlesDesc}
            </p>
          </div>
          <button
            type="button"
            onClick={handleClearFilters}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono text-cyan-600 dark:text-cyan-400 hover:underline bg-cyan-50 dark:bg-cyan-950/50 border border-cyan-200 dark:border-cyan-900/50 cursor-pointer"
          >
            <span>{t.blog.clearSearch}</span>
          </button>
        </div>
      ) : (
        /* 3 Dark Photography Cards Grid */
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {filteredItems.map((item, idx) => {
            const stats = getArticleReadingStats(item.id);
            return (
              <div
                key={item.id}
                onClick={() => onOpenArticle(item.id)}
                onMouseEnter={() => setHoveredIdx(idx)}
                onMouseLeave={() => setHoveredIdx(null)}
                className="group relative rounded-2xl border border-neutral-200 dark:border-neutral-800/80 bg-white dark:bg-neutral-950/60 overflow-hidden cursor-pointer hover:border-neutral-300 dark:hover:border-neutral-700 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
              >
                {/* Visual Container */}
                <div>
                  <div className="aspect-[4/3] w-full overflow-hidden bg-neutral-950 relative">
                    <div className="w-full h-full transform group-hover:scale-105 transition-transform duration-500">
                      {item.visual}
                    </div>

                    {/* Bottom Scrim */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-60 group-hover:opacity-40 transition-opacity" />

                    {/* PROMINENT TOP-LEFT FLOATING READING TIME BADGE */}
                    <div className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-neutral-950/85 backdrop-blur-md border border-neutral-700/80 text-white text-[10px] font-mono flex items-center gap-1.5 shadow-lg group-hover:border-cyan-500/70 transition-colors z-10">
                      <svg viewBox="0 0 24 24" className="w-3 h-3 text-cyan-400 stroke-current fill-none stroke-2">
                        <circle cx="12" cy="12" r="10" />
                        <polyline points="12 6 12 12 16 14" />
                      </svg>
                      <span className="font-medium tracking-wide">
                        {stats.minutes} {t.blog.minRead}
                      </span>
                    </div>

                    {/* Bottom-Right Pen / Edit Icon Badge */}
                    <div className="absolute bottom-3 right-3 w-7 h-7 rounded-full bg-neutral-900/80 border border-neutral-700/80 backdrop-blur-md flex items-center justify-center text-neutral-400 group-hover:text-white group-hover:border-neutral-500 transition-all shadow-md z-10">
                      <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 stroke-current fill-none stroke-2">
                        <path d="M12 20h9" />
                        <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z" />
                      </svg>
                    </div>
                  </div>

                  {/* Content metadata */}
                  <div className="p-4 space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <h3 className="text-xs font-mono font-semibold text-neutral-900 dark:text-neutral-200 group-hover:text-cyan-600 dark:group-hover:text-cyan-400 transition-colors truncate">
                        {item.title}
                      </h3>
                    </div>

                    {/* Metadata: Date and Estimated Reading Time Pill */}
                    <div className="flex items-center gap-2 text-[10px] font-mono text-neutral-500 dark:text-neutral-400">
                      <span>{item.date}</span>
                      <span aria-hidden="true" className="text-neutral-300 dark:text-neutral-700">·</span>
                      <span className="inline-flex items-center gap-1 text-cyan-700 dark:text-cyan-400 font-medium bg-cyan-50 dark:bg-cyan-950/50 px-1.5 py-0.5 rounded border border-cyan-200 dark:border-cyan-900/50">
                        <svg viewBox="0 0 24 24" className="w-3 h-3 stroke-current fill-none stroke-2">
                          <circle cx="12" cy="12" r="10" />
                          <polyline points="12 6 12 12 16 14" />
                        </svg>
                        <span>{stats.minutes} {t.blog.minRead}</span>
                      </span>
                    </div>

                    <p className="text-[11px] text-neutral-600 dark:text-neutral-400 leading-snug line-clamp-2">
                      {item.desc}
                    </p>
                  </div>
                </div>

                {/* Tag Pills at Card Bottom */}
                <div className="px-4 pb-4 pt-1 flex flex-wrap gap-1">
                  {item.tags.map((tag) => (
                    <button
                      key={tag}
                      type="button"
                      onClick={(e) => handleTagClick(tag, e)}
                      className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-neutral-100 dark:bg-neutral-900 text-neutral-500 dark:text-neutral-400 hover:text-cyan-600 dark:hover:text-cyan-400 hover:bg-cyan-50 dark:hover:bg-cyan-950/60 transition-colors"
                    >
                      #{tag}
                    </button>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
};
