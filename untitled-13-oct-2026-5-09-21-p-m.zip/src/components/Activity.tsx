import React, { useState, useEffect } from 'react';
import { Translations } from '../data/translations';

interface ActivityProps {
  t: Translations;
}

interface ContributionDay {
  date: string;
  count: number;
  level: number;
}

export const Activity: React.FC<ActivityProps> = ({ t }) => {
  const [hoveredCell, setHoveredCell] = useState<{ date: string; count: number; x: number; y: number } | null>(null);
  const [activeTab, setActiveTab] = useState<'all' | 'github' | 'twitter'>('all');
  const [totalContributions, setTotalContributions] = useState<number>(85);
  const [userLiked, setUserLiked] = useState<Record<number, boolean>>({});

  // 28-week Contribution Matrix based on real activity of notcalambur
  // 7 rows (Sun to Sat) x 28 columns
  const [matrixData, setMatrixData] = useState<ContributionDay[][]>(() => {
    const rawMatrix: number[][] = [
      // Sun
      [0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0],
      // Mon
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0],
      // Tue
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0],
      // Wed
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0],
      // Thu
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 2, 0, 0, 0, 0, 2, 0, 0, 0, 0],
      // Fri
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 2, 0, 0, 4, 2, 0, 0, 0],
      // Sat
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 1, 0, 0, 0],
    ];

    const today = new Date();
    const cols = 28;
    const grid: ContributionDay[][] = [];

    for (let r = 0; r < 7; r++) {
      const row: ContributionDay[] = [];
      for (let c = 0; c < cols; c++) {
        const daysAgo = (cols - 1 - c) * 7 + (6 - r);
        const dayDate = new Date(today);
        dayDate.setDate(today.getDate() - daysAgo);
        const level = rawMatrix[r][c] || 0;
        const count = level === 1 ? 2 : level === 2 ? 6 : level === 3 ? 8 : level === 4 ? 13 : 0;
        row.push({
          date: dayDate.toISOString().split('T')[0],
          level,
          count,
        });
      }
      grid.push(row);
    }
    return grid;
  });

  // Fetch real GitHub contribution data from public API with graceful fallback
  useEffect(() => {
    let isMounted = true;
    fetch('https://github-contributions-api.jogruber.de/v4/notcalambur?y=last')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (!isMounted || !data || !Array.isArray(data.contributions)) return;
        if (data.total && typeof data.total.lastYear === 'number') {
          setTotalContributions(data.total.lastYear);
        }
        const list = data.contributions;
        if (list.length >= 196) {
          const recent = list.slice(-196);
          const newGrid: ContributionDay[][] = [[], [], [], [], [], [], []];
          recent.forEach((item: any, idx: number) => {
            const rowIdx = idx % 7;
            newGrid[rowIdx].push({
              date: item.date,
              count: item.count,
              level: item.level,
            });
          });
          setMatrixData(newGrid);
        }
      })
      .catch(() => {
        // Keeps clean fallback
      });

    return () => {
      isMounted = false;
    };
  }, []);

  const getColorClass = (level: number) => {
    switch (level) {
      case 1:
        return 'bg-emerald-950/80 dark:bg-emerald-950 border-emerald-800/80 dark:border-emerald-800 text-emerald-200';
      case 2:
        return 'bg-emerald-700 dark:bg-emerald-700 border-emerald-600 dark:border-emerald-600 text-white';
      case 3:
        return 'bg-emerald-500 dark:bg-emerald-500 border-emerald-400 dark:border-emerald-400 text-white shadow-[0_0_8px_rgba(16,185,129,0.4)]';
      case 4:
        return 'bg-emerald-400 dark:bg-emerald-400 border-emerald-300 dark:border-emerald-300 text-white shadow-[0_0_12px_rgba(52,211,153,0.6)]';
      default:
        return 'bg-neutral-100 dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 hover:border-neutral-400 dark:hover:border-neutral-700';
    }
  };

  const months = ['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'];

  return (
    <section className="mb-14 w-full">
      {/* Section Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div className="flex items-center gap-2">
          <h2 className="text-xs font-mono tracking-widest text-neutral-500 dark:text-neutral-400 uppercase">
            {t.activityTitle}
          </h2>
          <span className="inline-flex items-center gap-1.5 text-[10px] font-mono tracking-wider text-emerald-600 dark:text-emerald-400 uppercase bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800/80 px-2 py-0.5 rounded-full">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            {t.liveFeed}
          </span>
        </div>

        {/* View Switcher: All Feeds | GitHub | Twitter / X */}
        <div className="flex items-center gap-1 p-1 bg-neutral-100 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800/80 rounded-xl text-xs font-mono">
          <button
            type="button"
            onClick={() => setActiveTab('all')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              activeTab === 'all'
                ? 'bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white font-semibold shadow-sm'
                : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            All Feeds
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('github')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              activeTab === 'github'
                ? 'bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white font-semibold shadow-sm'
                : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            GitHub
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('twitter')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              activeTab === 'twitter'
                ? 'bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white font-semibold shadow-sm'
                : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
            }`}
          >
            Twitter / X
          </button>
        </div>
      </div>

      {/* Expansive Full-Width Activity Cards Stack */}
      <div className="space-y-6 w-full">
        {/* CARD 1: GITHUB (Expanded Full-Width with Big Heat Squares & Real Data) */}
        {(activeTab === 'all' || activeTab === 'github') && (
          <div className="w-full p-6 md:p-8 rounded-3xl border border-neutral-200 dark:border-neutral-800/80 bg-white dark:bg-neutral-950/70 backdrop-blur-md relative group hover:border-neutral-300 dark:hover:border-neutral-700 shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden">
            {/* Header */}
            <div className="flex items-center justify-between mb-5 flex-wrap gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-neutral-100 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 flex items-center justify-center text-neutral-900 dark:text-white shadow-sm">
                  <svg viewBox="0 0 24 24" className="w-5 h-5 fill-current">
                    <path d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.53 1.032 1.53 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z" />
                  </svg>
                </div>
                <div>
                  <h3 className="font-mono text-base md:text-lg font-bold text-neutral-900 dark:text-white flex items-center gap-2">
                    GitHub Activity Matrix
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800">
                      Real Data
                    </span>
                  </h3>
                  <p className="text-xs font-mono text-neutral-500 dark:text-neutral-400">
                    @notcalambur · Blue Team SOC automation, Threat Intel & AI security tools
                  </p>
                </div>
              </div>

              <a
                href="https://github.com/notcalambur"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-xs font-mono text-neutral-700 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-white px-3 py-1.5 rounded-xl border border-neutral-300 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900/80 hover:border-neutral-400 dark:hover:border-neutral-600 transition-colors shadow-sm"
              >
                <span>{t.github.viewProfile}</span>
                <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 stroke-current fill-none stroke-2">
                  <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                  <polyline points="15 3 21 3 21 9" />
                  <line x1="10" y1="14" x2="21" y2="3" />
                </svg>
              </a>
            </div>

            {/* Real Public Repos Pills */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
              <a
                href="https://github.com/notcalambur/sentinel-bench"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 rounded-2xl border border-neutral-200 dark:border-neutral-800/80 bg-neutral-50/60 dark:bg-neutral-900/40 hover:border-cyan-500/50 transition-all flex items-start gap-3 group/repo"
              >
                <div className="w-7 h-7 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-600 dark:text-cyan-400 shrink-0 mt-0.5">
                  <span className="text-xs font-mono font-bold">SB</span>
                </div>
                <div className="min-w-0 flex-1 space-y-0.5">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold text-neutral-900 dark:text-white group-hover/repo:text-cyan-600 dark:group-hover/repo:text-cyan-400 transition-colors">
                      sentinel-bench
                    </span>
                    <span className="text-[10px] font-mono text-neutral-500">Python / Astro</span>
                  </div>
                  <p className="text-[11px] text-neutral-600 dark:text-neutral-400 truncate">
                    Personal Cyber Threat Intel Lab · CISA KEV + EPSS
                  </p>
                </div>
              </a>

              <a
                href="https://github.com/notcalambur/vibecode-scanner"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 rounded-2xl border border-neutral-200 dark:border-neutral-800/80 bg-neutral-50/60 dark:bg-neutral-900/40 hover:border-emerald-500/50 transition-all flex items-start gap-3 group/repo"
              >
                <div className="w-7 h-7 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5">
                  <span className="text-xs font-mono font-bold">VC</span>
                </div>
                <div className="min-w-0 flex-1 space-y-0.5">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold text-neutral-900 dark:text-white group-hover/repo:text-emerald-600 dark:group-repo:text-emerald-400 transition-colors">
                      vibecode-scanner
                    </span>
                    <span className="text-[10px] font-mono text-neutral-500">TypeScript / Next.js</span>
                  </div>
                  <p className="text-[11px] text-neutral-600 dark:text-neutral-400 truncate">
                    Free AI Vibe Coding Security Scanner with fix prompts
                  </p>
                </div>
              </a>
            </div>

            {/* Months Header spanning wide */}
            <div className="flex text-[11px] font-mono text-neutral-400 dark:text-neutral-500 justify-between pl-8 pr-3 mb-2">
              {months.map((m) => (
                <span key={m}>{m}</span>
              ))}
            </div>

            {/* BIG Heat Squares Grid (Expansive Matrix) */}
            <div className="overflow-x-auto pb-2 scrollbar-none">
              <div className="flex gap-3 items-center justify-between min-w-[720px] py-2">
                {/* Day Labels */}
                <div className="flex flex-col justify-between h-[154px] sm:h-[168px] text-[10px] font-mono text-neutral-400 select-none py-1">
                  <span className="h-4">Mon</span>
                  <span className="h-4">Wed</span>
                  <span className="h-4">Fri</span>
                </div>

                {/* Grid columns with BIGGER squares */}
                <div className="grid grid-flow-col grid-rows-7 gap-2 flex-1">
                  {Array.from({ length: 28 }).map((_, colIdx) => (
                    <React.Fragment key={colIdx}>
                      {Array.from({ length: 7 }).map((_, rowIdx) => {
                        const cell = matrixData[rowIdx]?.[colIdx] || {
                          date: `Day ${colIdx * 7 + rowIdx}`,
                          count: 0,
                          level: 0,
                        };
                        return (
                          <div
                            key={`${colIdx}-${rowIdx}`}
                            onMouseEnter={(e) => {
                              const rect = e.currentTarget.getBoundingClientRect();
                              setHoveredCell({
                                date: cell.date,
                                count: cell.count,
                                x: rect.left,
                                y: rect.top,
                              });
                            }}
                            onMouseLeave={() => setHoveredCell(null)}
                            className={`w-4 h-4 sm:w-5 sm:h-5 rounded-md border ${getColorClass(
                              cell.level
                            )} hover:scale-125 hover:z-20 hover:ring-2 hover:ring-neutral-900 dark:hover:ring-white transition-all duration-150 cursor-pointer`}
                          />
                        );
                      })}
                    </React.Fragment>
                  ))}
                </div>
              </div>
            </div>

            {/* Floating Tooltip */}
            {hoveredCell && (
              <div className="absolute top-20 left-1/2 -translate-x-1/2 bg-neutral-900 dark:bg-neutral-900 border border-neutral-700 text-neutral-100 text-xs font-mono px-3 py-1.5 rounded-xl shadow-2xl z-30 pointer-events-none whitespace-nowrap">
                <span className="font-bold text-emerald-400">{hoveredCell.count}</span>{' '}
                {t.github.contributions} on {hoveredCell.date}
              </div>
            )}

            {/* Footer with stats and legend */}
            <div className="pt-4 mt-2 border-t border-neutral-200 dark:border-neutral-900 flex flex-wrap items-center justify-between gap-3 text-xs font-mono text-neutral-600 dark:text-neutral-400">
              <div className="flex items-center gap-4 flex-wrap">
                <span className="text-neutral-900 dark:text-white font-semibold">
                  {totalContributions} {t.github.contributions} in the last year
                </span>
                <span className="text-neutral-300 dark:text-neutral-700">·</span>
                <span className="text-emerald-600 dark:text-emerald-400">Active repo commits</span>
                <span className="text-neutral-300 dark:text-neutral-700">·</span>
                <span>2 public cybersecurity tools</span>
              </div>

              {/* Legend with BIGGER squares */}
              <div className="flex items-center gap-2">
                <span className="text-[11px] text-neutral-400">{t.github.less}</span>
                <div className="flex items-center gap-1.5">
                  <span className="w-3.5 h-3.5 rounded-md bg-neutral-100 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800" />
                  <span className="w-3.5 h-3.5 rounded-md bg-emerald-950/80 dark:bg-emerald-950 border border-emerald-800" />
                  <span className="w-3.5 h-3.5 rounded-md bg-emerald-700 border border-emerald-600" />
                  <span className="w-3.5 h-3.5 rounded-md bg-emerald-500 border border-emerald-400" />
                  <span className="w-3.5 h-3.5 rounded-md bg-emerald-400 border border-emerald-300" />
                </div>
                <span className="text-[11px] text-neutral-400">{t.github.more}</span>
              </div>
            </div>
          </div>
        )}

        {/* CARD 2: TWITTER / X (Expanded Full-Width with Real Posts Feed) */}
        {(activeTab === 'all' || activeTab === 'twitter') && (
          <div className="w-full p-6 md:p-8 rounded-3xl border border-neutral-200 dark:border-neutral-800/80 bg-white dark:bg-neutral-950/70 backdrop-blur-md relative group hover:border-neutral-300 dark:hover:border-neutral-700 shadow-sm hover:shadow-xl transition-all duration-300">
            {/* Header */}
            <div className="flex items-center justify-between mb-6 flex-wrap gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-neutral-100 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 flex items-center justify-center text-neutral-900 dark:text-white shadow-sm">
                  <svg viewBox="0 0 24 24" className="w-4 h-4 fill-current">
                    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                  </svg>
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-mono text-base md:text-lg font-bold text-neutral-900 dark:text-white">
                      calambur (@calamburssj)
                    </h3>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-sky-100 dark:bg-sky-950/80 text-sky-700 dark:text-sky-400 border border-sky-200 dark:border-sky-800">
                      Blue Team & AI Insights
                    </span>
                  </div>
                  <p className="text-xs font-mono text-neutral-500 dark:text-neutral-400">
                    🇦🇷 • Cybersecurity Analyst • Software Developer • Crypto Trader • I like to build & break things too.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <span className="text-xs font-mono text-neutral-500 hidden sm:inline">
                  <strong className="text-neutral-900 dark:text-white">2,187</strong> posts · <strong className="text-neutral-900 dark:text-white">133</strong> followers
                </span>
                <a
                  href="https://x.com/calamburssj"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-mono text-neutral-700 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-white px-3 py-1.5 rounded-xl border border-neutral-300 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900/80 hover:border-neutral-400 dark:hover:border-neutral-600 transition-colors shadow-sm"
                >
                  <span>{t.twitter.viewProfile}</span>
                  <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 stroke-current fill-none stroke-2">
                    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                    <polyline points="15 3 21 3 21 9" />
                    <line x1="10" y1="14" x2="21" y2="3" />
                  </svg>
                </a>
              </div>
            </div>

            {/* Real Tweets Feed */}
            <div className="space-y-4">
              {t.twitter.tweets.map((tweet, idx) => (
                <div
                  key={idx}
                  className="p-4 sm:p-5 rounded-2xl bg-neutral-50/70 dark:bg-neutral-900/40 border border-neutral-200/80 dark:border-neutral-800/80 flex items-start gap-4 hover:border-neutral-300 dark:hover:border-neutral-700 transition-colors"
                >
                  {/* Avatar thumbnail */}
                  <div className="w-10 h-10 rounded-full overflow-hidden border border-neutral-300 dark:border-neutral-700 shrink-0 bg-neutral-900">
                    <img
                      src="/MvkgKFcj_400x400.jpg"
                      alt="Calambur"
                      className="w-full h-full object-cover"
                    />
                  </div>

                  <div className="flex-1 space-y-2 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs sm:text-sm font-bold font-mono text-neutral-900 dark:text-white">
                          calambur
                        </span>
                        <span className="text-xs font-mono text-neutral-400 dark:text-neutral-500">
                          @calamburssj
                        </span>
                        <span className="text-xs text-neutral-300 dark:text-neutral-700">·</span>
                        <span className="text-xs font-mono text-neutral-400 dark:text-neutral-500">
                          {tweet.time}
                        </span>
                      </div>
                      <a
                        href="https://x.com/calamburssj"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-neutral-400 hover:text-neutral-900 dark:hover:text-white transition-colors"
                        title="View on X"
                      >
                        <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 stroke-current fill-none stroke-2">
                          <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                          <polyline points="15 3 21 3 21 9" />
                          <line x1="10" y1="14" x2="21" y2="3" />
                        </svg>
                      </a>
                    </div>

                    <p className="text-xs sm:text-sm font-sans text-neutral-800 dark:text-neutral-200 leading-relaxed break-words">
                      {tweet.text}
                    </p>

                    {/* Interactive Post Actions */}
                    <div className="flex items-center gap-6 pt-2 text-xs font-mono text-neutral-500">
                      <button
                        type="button"
                        onClick={() =>
                          setUserLiked((prev) => ({ ...prev, [idx]: !prev[idx] }))
                        }
                        className={`flex items-center gap-1.5 transition-colors ${
                          userLiked[idx]
                            ? 'text-red-500'
                            : 'hover:text-red-500'
                        }`}
                      >
                        <svg
                          viewBox="0 0 24 24"
                          className={`w-3.5 h-3.5 ${
                            userLiked[idx] ? 'fill-current stroke-current' : 'stroke-current fill-none stroke-2'
                          }`}
                        >
                          <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
                        </svg>
                        <span>{tweet.likes + (userLiked[idx] ? 1 : 0)}</span>
                      </button>

                      <div className="flex items-center gap-1.5 hover:text-emerald-500 transition-colors">
                        <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 stroke-current fill-none stroke-2">
                          <polyline points="17 1 21 5 17 9" />
                          <path d="M3 11V9a4 4 0 0 1 4-4h14" />
                          <polyline points="7 23 3 19 7 15" />
                          <path d="M21 13v2a4 4 0 0 1-4 4H3" />
                        </svg>
                        <span>{tweet.retweets}</span>
                      </div>

                      <div className="flex items-center gap-1.5 hover:text-sky-500 transition-colors">
                        <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 stroke-current fill-none stroke-2">
                          <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
                        </svg>
                        <span>{idx + 3}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Footer */}
            <div className="pt-4 mt-4 border-t border-neutral-200 dark:border-neutral-900 flex justify-between text-xs font-mono text-neutral-500 dark:text-neutral-400">
              <span>{t.twitter.recentPosts}</span>
              <span className="text-neutral-500">{t.twitter.lastPosted}</span>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
