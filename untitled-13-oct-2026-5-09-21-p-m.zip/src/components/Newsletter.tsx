import React, { useState, useEffect } from 'react';
import { Translations } from '../data/translations';

interface NewsletterProps {
  t: Translations;
}

export const Newsletter: React.FC<NewsletterProps> = ({ t }) => {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle' | 'redirecting' | 'subscribed' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');
  const [savedEmail, setSavedEmail] = useState<string | null>(null);

  useEffect(() => {
    try {
      const stored = localStorage.getItem('calambur_substack_subscribed');
      if (stored) {
        setSavedEmail(stored);
        setStatus('subscribed');
      }
    } catch {
      // ignore storage access issues
    }
  }, []);

  const validateEmail = (val: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val.trim());
  };

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateEmail(email)) {
      setStatus('error');
      setErrorMessage(t.footerNewsletter.invalidEmail);
      return;
    }

    setStatus('redirecting');
    setErrorMessage('');

    try {
      localStorage.setItem('calambur_substack_subscribed', email.trim());
      setSavedEmail(email.trim());
    } catch {
      // ignore
    }

    // Direct link to Substack publication/profile subscribe with prefilled email
    const substackSubscribeUrl = `https://substack.com/@notcalambur`;
    
    // Open Substack in a new tab to complete subscription
    window.open(substackSubscribeUrl, '_blank', 'noopener,noreferrer');

    setTimeout(() => {
      setStatus('subscribed');
      setEmail('');
    }, 1500);
  };

  return (
    <div className="w-full max-w-xl mx-auto my-6 p-5 sm:p-6 rounded-2xl border border-neutral-200 dark:border-neutral-800/80 bg-white dark:bg-neutral-950/70 shadow-sm backdrop-blur-sm transition-all duration-300">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
        <div className="flex items-center gap-2">
          {/* Substack Icon */}
          <div className="w-6 h-6 rounded-md bg-[#FF6719]/15 flex items-center justify-center text-[#FF6719] border border-[#FF6719]/30">
            <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 fill-current">
              <path d="M22.539 8.242H1.46V5.406h21.08v2.836zM1.46 10.812V24L12 18.11 22.54 24V10.812H1.46zM22.54 0H1.46v2.836h21.08V0z" />
            </svg>
          </div>
          <h3 className="text-xs font-mono font-semibold tracking-wider text-neutral-900 dark:text-neutral-200 uppercase">
            {t.footerNewsletter.title}
          </h3>
        </div>
        <span className="self-start sm:self-auto text-[10px] font-mono tracking-widest text-[#FF6719] bg-[#FF6719]/10 px-2 py-0.5 rounded border border-[#FF6719]/25 uppercase font-medium">
          {t.footerNewsletter.badge}
        </span>
      </div>

      <p className="text-xs text-neutral-600 dark:text-neutral-400 font-mono mb-4 leading-relaxed">
        {t.footerNewsletter.description}
      </p>

      {status === 'subscribed' ? (
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-800 dark:text-emerald-300 font-mono text-xs">
          <div className="flex items-center gap-2">
            <svg viewBox="0 0 24 24" className="w-4 h-4 stroke-current fill-none stroke-2 text-emerald-500">
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
              <polyline points="22 4 12 14.01 9 11.01" />
            </svg>
            <span>
              {t.footerNewsletter.alreadySubscribed}{' '}
              {savedEmail && <span className="opacity-75 text-[11px]">({savedEmail})</span>}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <a
              href="https://substack.com/@notcalambur"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[11px] underline underline-offset-2 hover:text-emerald-950 dark:hover:text-emerald-100 transition-colors"
            >
              @notcalambur ↗
            </a>
            <button
              type="button"
              onClick={() => {
                setStatus('idle');
                setEmail('');
              }}
              className="text-[10px] text-neutral-500 dark:text-neutral-400 hover:text-neutral-800 dark:hover:text-neutral-200 underline"
            >
              Change
            </button>
          </div>
        </div>
      ) : (
        <form onSubmit={handleSubscribe} className="space-y-2">
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative flex-1">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-neutral-400">
                <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 stroke-current fill-none stroke-2">
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                  <polyline points="22,6 12,13 2,6" />
                </svg>
              </div>
              <input
                type="email"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  if (status === 'error') setStatus('idle');
                }}
                placeholder={t.footerNewsletter.placeholder}
                required
                className="w-full pl-9 pr-3 py-2 text-xs font-mono rounded-xl bg-neutral-50 dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-800 text-neutral-900 dark:text-neutral-100 placeholder-neutral-400 focus:outline-none focus:ring-1 focus:ring-[#FF6719] focus:border-[#FF6719] transition-all"
              />
            </div>

            <button
              type="submit"
              disabled={status === 'redirecting'}
              className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-mono font-medium rounded-xl text-white bg-neutral-900 dark:bg-neutral-100 dark:text-neutral-900 hover:bg-[#FF6719] dark:hover:bg-[#FF6719] dark:hover:text-white transition-all shadow-sm disabled:opacity-50 cursor-pointer active:scale-95"
            >
              {status === 'redirecting' ? (
                <>
                  <svg className="animate-spin w-3 h-3 stroke-current" viewBox="0 0 24 24" fill="none">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
                  </svg>
                  <span>...</span>
                </>
              ) : (
                <>
                  <span>{t.footerNewsletter.button}</span>
                  <svg viewBox="0 0 24 24" className="w-3 h-3 stroke-current fill-none stroke-2">
                    <line x1="5" y1="12" x2="19" y2="12" />
                    <polyline points="12 5 19 12 12 19" />
                  </svg>
                </>
              )}
            </button>
          </div>

          {status === 'error' && errorMessage && (
            <p className="text-[11px] font-mono text-red-500 flex items-center gap-1.5 pt-1">
              <svg viewBox="0 0 24 24" className="w-3 h-3 stroke-current fill-none stroke-2">
                <circle cx="12" cy="12" r="10" />
                <line x1="12" y1="8" x2="12" y2="12" />
                <line x1="12" y1="16" x2="12.01" y2="16" />
              </svg>
              <span>{errorMessage}</span>
            </p>
          )}

          {status === 'redirecting' && (
            <p className="text-[11px] font-mono text-cyan-600 dark:text-cyan-400 flex items-center gap-1.5 pt-1 animate-pulse">
              <svg viewBox="0 0 24 24" className="w-3 h-3 stroke-current fill-none stroke-2">
                <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                <polyline points="15 3 21 3 21 9" />
                <line x1="10" y1="14" x2="21" y2="3" />
              </svg>
              <span>{t.footerNewsletter.redirecting}</span>
            </p>
          )}
        </form>
      )}

      {/* Substack Direct Link footer */}
      <div className="mt-3 pt-3 border-t border-neutral-100 dark:border-neutral-900 flex items-center justify-between text-[11px] font-mono text-neutral-500 dark:text-neutral-500">
        <a
          href="https://substack.com/@notcalambur"
          target="_blank"
          rel="noopener noreferrer"
          className="hover:text-[#FF6719] transition-colors inline-flex items-center gap-1"
        >
          <span>{t.footerNewsletter.readPastIssues}</span>
          <svg viewBox="0 0 24 24" className="w-2.5 h-2.5 stroke-current fill-none stroke-2">
            <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
            <polyline points="15 3 21 3 21 9" />
            <line x1="10" y1="14" x2="21" y2="3" />
          </svg>
        </a>
        <span className="text-[10px] opacity-60">Calambur Substack</span>
      </div>
    </div>
  );
};
