import React from 'react';
import { Translations } from '../data/translations';
import { getArticleReadingStats, blogArticlesContent } from '../utils/readingTime';

interface BlogModalProps {
  articleId: number | null;
  onClose: () => void;
  t: Translations;
}

export const BlogModal: React.FC<BlogModalProps> = ({ articleId, onClose, t }) => {
  if (!articleId) return null;

  const isEs = t.comingSoon === 'Próximamente';
  const readingStats = getArticleReadingStats(articleId, isEs ? 'es' : 'en');

  const getArticleDetails = () => {
    const data = blogArticlesContent[articleId];
    const paras = (isEs ? data?.paragraphs.es : data?.paragraphs.en) || data?.paragraphs.en || [];
    switch (articleId) {
      case 1:
        return {
          title: t.blog.item1.title,
          desc: t.blog.item1.desc,
          specs: data?.specs || [],
          paragraphs: paras
        };
      case 2:
        return {
          title: t.blog.item2.title,
          desc: t.blog.item2.desc,
          specs: data?.specs || [],
          paragraphs: paras
        };
      case 3:
      default:
        return {
          title: t.blog.item3.title,
          desc: t.blog.item3.desc,
          specs: data?.specs || [],
          paragraphs: paras
        };
    }
  };

  const article = getArticleDetails();
  if (!article) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div 
        id="blog-modal-content"
        className="relative w-full max-w-lg max-h-[85vh] overflow-y-auto p-6 bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-3xl shadow-2xl space-y-4"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="sticky top-0 float-right text-neutral-400 hover:text-neutral-900 dark:hover:text-white p-1 rounded-xl hover:bg-neutral-100 dark:hover:bg-neutral-900 transition-colors z-20"
          aria-label="Close modal"
        >
          <svg viewBox="0 0 24 24" className="w-5 h-5 stroke-current fill-none stroke-2">
            <line x1="18" y1="6" x2="6" y2="18" />
            <line x1="6" y1="6" x2="18" y2="18" />
          </svg>
        </button>

        {/* Header */}
        <div>
          <div className="flex items-center gap-2 text-[10px] font-mono text-neutral-500 flex-wrap">
            <span className="tracking-widest uppercase">PHOTOGRAPHY LOG</span>
            <span aria-hidden="true" className="text-neutral-300 dark:text-neutral-700">·</span>
            {/* Reading Time Pill */}
            <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-cyan-50 dark:bg-cyan-950/60 border border-cyan-200 dark:border-cyan-800/80 text-cyan-700 dark:text-cyan-300 font-medium">
              <svg viewBox="0 0 24 24" className="w-3 h-3 stroke-current fill-none stroke-2">
                <circle cx="12" cy="12" r="10" />
                <polyline points="12 6 12 12 16 14" />
              </svg>
              <span>{readingStats.minutes} {t.blog.minRead}</span>
              <span className="text-cyan-400 dark:text-cyan-600">·</span>
              <span>~{readingStats.words} words</span>
            </span>
          </div>
          <h3 className="font-mono text-xl font-bold text-neutral-900 dark:text-white mt-2">
            {article.title}
          </h3>
          <p className="text-xs text-neutral-600 dark:text-neutral-400 mt-1">
            {article.desc}
          </p>
        </div>

        {/* Specs Table */}
        <div className="p-3.5 bg-neutral-50 dark:bg-neutral-900/60 border border-neutral-200 dark:border-neutral-800/80 rounded-2xl space-y-2">
          <div className="text-[10px] font-mono text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">Gear & Specs</div>
          <div className="grid grid-cols-2 gap-2">
            {article.specs.map((s, idx) => (
              <div key={idx} className="space-y-0.5">
                <div className="text-[9px] font-mono text-neutral-400 dark:text-neutral-500">{s.label}</div>
                <div className="text-[11px] font-mono text-neutral-800 dark:text-neutral-300 truncate" title={s.val}>{s.val}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Narrative */}
        <div className="space-y-2 text-xs text-neutral-700 dark:text-neutral-300 leading-relaxed font-sans">
          {article.paragraphs.map((p, idx) => (
            <p key={idx}>{p}</p>
          ))}
        </div>

        {/* Footer */}
        <div className="pt-2 border-t border-neutral-200 dark:border-neutral-900 flex justify-between items-center text-[10px] font-mono text-neutral-500">
          <span>{readingStats.minutes} {t.blog.minRead} · Draft in review</span>
          <button
            type="button"
            onClick={onClose}
            className="px-3.5 py-1.5 rounded-xl bg-neutral-100 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 text-neutral-700 dark:text-neutral-300 hover:text-black dark:hover:text-white hover:border-neutral-400 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
