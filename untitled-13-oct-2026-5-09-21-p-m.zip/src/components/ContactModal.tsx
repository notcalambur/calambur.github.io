import React, { useState } from 'react';
import { Translations } from '../data/translations';

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  t: Translations;
}

export const ContactModal: React.FC<ContactModalProps> = ({ isOpen, onClose, t }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [status, setStatus] = useState<'idle' | 'sending' | 'sent'>('idle');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const targetEmail = t.openCommissions?.email || 'mr.indie.cybersec@gmail.com';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !message) return;
    setStatus('sending');
    setTimeout(() => {
      setStatus('sent');
      setTimeout(() => {
        setStatus('idle');
        setName('');
        setEmail('');
        setMessage('');
        onClose();
      }, 2000);
    }, 800);
  };

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(targetEmail);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div 
        className="relative w-full max-w-md p-6 bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-3xl shadow-2xl space-y-4"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 text-neutral-400 hover:text-neutral-900 dark:hover:text-white p-1 rounded-xl hover:bg-neutral-100 dark:hover:bg-neutral-900 transition-colors"
          aria-label="Close modal"
        >
          <svg viewBox="0 0 24 24" className="w-5 h-5 stroke-current fill-none stroke-2">
            <line x1="18" y1="6" x2="6" y2="18" />
            <line x1="6" y1="6" x2="18" y2="18" />
          </svg>
        </button>

        {/* Header */}
        <div>
          <h3 className="font-mono text-lg font-bold text-neutral-900 dark:text-white">
            {t.contactModal.title}
          </h3>
          <p className="text-xs text-neutral-600 dark:text-neutral-400 mt-1">
            {t.contactModal.subtitle}
          </p>
        </div>

        {/* Quick Email Copy Row */}
        <div className="p-3 bg-neutral-50 dark:bg-neutral-900/60 border border-neutral-200 dark:border-neutral-800/80 rounded-xl flex items-center justify-between">
          <div className="flex items-center gap-2">
            <svg viewBox="0 0 24 24" className="w-4 h-4 text-emerald-500 stroke-current fill-none stroke-2">
              <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
              <polyline points="22,6 12,13 2,6" />
            </svg>
            <span className="text-xs font-mono text-neutral-800 dark:text-neutral-200 truncate">
              {targetEmail}
            </span>
          </div>
          <button
            type="button"
            onClick={handleCopyEmail}
            className="text-[11px] font-mono text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white underline underline-offset-2 ml-2 shrink-0"
          >
            {copied ? t.contactModal.copied : t.contactModal.copyEmail}
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className="block text-[11px] font-mono text-neutral-600 dark:text-neutral-400 mb-1">
              {t.contactModal.nameLabel}
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl text-xs text-neutral-900 dark:text-white focus:outline-none focus:border-neutral-400 dark:focus:border-neutral-600 font-mono"
              placeholder="Alex Smith"
            />
          </div>

          <div>
            <label className="block text-[11px] font-mono text-neutral-600 dark:text-neutral-400 mb-1">
              {t.contactModal.emailLabel}
            </label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl text-xs text-neutral-900 dark:text-white focus:outline-none focus:border-neutral-400 dark:focus:border-neutral-600 font-mono"
              placeholder="alex@company.com"
            />
          </div>

          <div>
            <label className="block text-[11px] font-mono text-neutral-600 dark:text-neutral-400 mb-1">
              {t.contactModal.messageLabel}
            </label>
            <textarea
              required
              rows={3}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl text-xs text-neutral-900 dark:text-white focus:outline-none focus:border-neutral-400 dark:focus:border-neutral-600 font-mono resize-none"
              placeholder="I'd like to collaborate on..."
            />
          </div>

          <button
            type="submit"
            disabled={status !== 'idle'}
            className="w-full py-2.5 rounded-xl bg-neutral-900 text-white dark:bg-white dark:text-black font-mono text-xs font-semibold hover:bg-neutral-800 dark:hover:bg-neutral-200 transition-colors disabled:opacity-50"
          >
            {status === 'sending'
              ? t.contactModal.sending
              : status === 'sent'
              ? t.contactModal.sent
              : t.contactModal.sendButton}
          </button>
        </form>
      </div>
    </div>
  );
};
