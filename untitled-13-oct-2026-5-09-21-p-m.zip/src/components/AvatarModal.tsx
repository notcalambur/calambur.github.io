import React from 'react';

interface AvatarModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AvatarModal: React.FC<AvatarModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-lg animate-fadeIn">
      <div 
        className="relative w-full max-w-md p-6 bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-3xl shadow-2xl flex flex-col items-center text-center space-y-4"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 text-neutral-400 hover:text-neutral-900 dark:hover:text-white p-1.5 rounded-xl hover:bg-neutral-100 dark:hover:bg-neutral-900 transition-colors"
          aria-label="Close modal"
        >
          <svg viewBox="0 0 24 24" className="w-5 h-5 stroke-current fill-none stroke-2">
            <line x1="18" y1="6" x2="6" y2="18" />
            <line x1="6" y1="6" x2="18" y2="18" />
          </svg>
        </button>

        {/* Header */}
        <div>
          <span className="text-[10px] font-mono tracking-widest text-neutral-500 uppercase">PROFILE PHOTO</span>
          <h3 className="font-mono text-lg font-bold text-neutral-900 dark:text-white mt-0.5">
            Calambur
          </h3>
          <p className="text-xs text-neutral-600 dark:text-neutral-400">
            Cybersecurity Blue Team & AI Engineering
          </p>
        </div>

        {/* Big Avatar Presentation with the exact user provided photo */}
        <div className="py-2">
          <div className="w-56 h-56 rounded-full overflow-hidden border-2 border-neutral-300 dark:border-neutral-700 shadow-2xl relative bg-neutral-900">
            <img
              src="/MvkgKFcj_400x400.jpg"
              alt="Calambur"
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        {/* Specifications card */}
        <div className="w-full p-3.5 bg-neutral-50 dark:bg-neutral-900/60 border border-neutral-200 dark:border-neutral-800/80 rounded-2xl text-left space-y-1.5 text-[11px] font-mono">
          <div className="flex justify-between text-neutral-500 dark:text-neutral-400">
            <span>Identifier</span>
            <span className="text-neutral-900 dark:text-neutral-200">@calamburssj / @notcalambur</span>
          </div>
          <div className="flex justify-between text-neutral-500 dark:text-neutral-400">
            <span>Specialization</span>
            <span className="text-neutral-900 dark:text-neutral-200">Blue Team & AI Side Projects</span>
          </div>
          <div className="flex justify-between text-neutral-500 dark:text-neutral-400">
            <span>Commissions</span>
            <span className="text-emerald-600 dark:text-emerald-400">Open (mr.indie.cybersec@gmail.com)</span>
          </div>
        </div>

        {/* Close action */}
        <button
          type="button"
          onClick={onClose}
          className="w-full py-2.5 rounded-xl bg-neutral-900 text-white dark:bg-neutral-900 dark:text-neutral-300 border border-neutral-200 dark:border-neutral-800 text-xs font-mono hover:bg-neutral-800 dark:hover:text-white dark:hover:border-neutral-600 transition-colors shadow-sm"
        >
          Back to Portfolio
        </button>
      </div>
    </div>
  );
};
