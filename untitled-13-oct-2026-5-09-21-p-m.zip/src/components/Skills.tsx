import React, { useState } from 'react';
import { Translations } from '../data/translations';

interface SkillsProps {
  t: Translations;
}

interface SkillItem {
  name: string;
  category: string;
  icon: React.ReactNode;
}

export const Skills: React.FC<SkillsProps> = ({ t }) => {
  const [activeSkill, setActiveSkill] = useState<string | null>(null);

  const skills: SkillItem[] = [
    // Row 1
    {
      name: 'Python (Security & AI)',
      category: 'Threat Automation & Tooling',
      icon: (
        <svg viewBox="0 0 24 24" className="w-6 h-6 stroke-current fill-none stroke-[1.5]">
          <path d="M12 2C8 2 6 3.5 6 6v3h6v1H4a2 2 0 0 0-2 2v6c0 3 2 4 6 4h2v-3a3 3 0 0 1 3-3h5a2 2 0 0 0 2-2V6c0-2.5-2-4-6-4h-2zm-2 2a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm4 16a1 1 0 1 1 0-2 1 1 0 0 1 0 2z" />
        </svg>
      ),
    },
    {
      name: 'Linux & Kernel Internals',
      category: 'SOC & Telemetry Analysis',
      icon: (
        <svg viewBox="0 0 24 24" className="w-6 h-6 stroke-current fill-none stroke-[1.5]">
          <rect x="2" y="3" width="20" height="14" rx="2" />
          <line x1="8" y1="21" x2="16" y2="21" />
          <line x1="12" y1="17" x2="12" y2="21" />
          <path d="M6 8l3 3-3 3" />
          <line x1="11" y1="14" x2="15" y2="14" />
        </svg>
      ),
    },
    {
      name: 'SIEM & Threat Hunting',
      category: 'Blue Team Detection',
      icon: (
        <svg viewBox="0 0 24 24" className="w-6 h-6 stroke-current fill-none stroke-[1.5]">
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
          <path d="M9 12l2 2 4-4" />
        </svg>
      ),
    },
    {
      name: 'TypeScript',
      category: 'Typed Systems & Tools',
      icon: (
        <div className="font-mono text-sm font-bold border border-current rounded px-1.5 py-0.5 leading-none">
          TS
        </div>
      ),
    },

    // Row 2
    {
      name: 'Next.js & React',
      category: 'Fullstack UI Engineering',
      icon: (
        <svg viewBox="0 0 24 24" className="w-6 h-6 stroke-current fill-none stroke-[1.5]">
          <path d="M12 2L2 7l10 5 10-5-10-5z" />
          <path d="M2 17l10 5 10-5" />
          <path d="M2 12l10 5 10-5" />
        </svg>
      ),
    },
    {
      name: 'CISA KEV & NVD',
      category: 'Vulnerability Intelligence',
      icon: (
        <svg viewBox="0 0 24 24" className="w-6 h-6 stroke-current fill-none stroke-[1.5]">
          <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
          <path d="M7 11V7a5 5 0 0 1 10 0v4" />
        </svg>
      ),
    },
    {
      name: 'Docker & Sandboxing',
      category: 'Isolation & Lab Environments',
      icon: (
        <svg viewBox="0 0 24 24" className="w-6 h-6 stroke-current fill-none stroke-[1.5]">
          <rect x="2" y="7" width="20" height="14" rx="2" />
          <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" />
        </svg>
      ),
    },
    {
      name: 'Wireshark & PCAP',
      category: 'Network Protocol Forensics',
      icon: (
        <svg viewBox="0 0 24 24" className="w-6 h-6 stroke-current fill-none stroke-[1.5]">
          <path d="M2 12h20" />
          <path d="M20 12v8H4v-8" />
          <path d="M4 4h16v4H4z" />
        </svg>
      ),
    },

    // Row 3
    {
      name: 'Astro',
      category: 'Lightweight HUD & Static Sites',
      icon: (
        <svg viewBox="0 0 24 24" className="w-6 h-6 stroke-current fill-none stroke-[1.5]">
          <path d="M12 2L3 21h18L12 2z" />
          <circle cx="12" cy="14" r="2" />
        </svg>
      ),
    },
    {
      name: 'Git & Version Control',
      category: 'Collaboration & CI',
      icon: (
        <svg viewBox="0 0 24 24" className="w-6 h-6 stroke-current fill-none stroke-[1.5]">
          <circle cx="6" cy="6" r="3" />
          <circle cx="6" cy="18" r="3" />
          <circle cx="18" cy="12" r="3" />
          <line x1="6" y1="9" x2="6" y2="15" />
          <path d="M9 18h3a6 6 0 0 0 6-6" />
        </svg>
      ),
    },
    {
      name: 'YARA Rules & Sigma',
      category: 'Threat Detection Standards',
      icon: (
        <svg viewBox="0 0 24 24" className="w-6 h-6 stroke-current fill-none stroke-[1.5]">
          <circle cx="12" cy="12" r="10" />
          <path d="m4.93 4.93 4.24 4.24" />
          <path d="m14.83 9.17 4.24-4.24" />
          <path d="m14.83 14.83 4.24 4.24" />
          <path d="m9.17 14.83-4.24 4.24" />
          <circle cx="12" cy="12" r="4" />
        </svg>
      ),
    },
    {
      name: 'Tailwind CSS',
      category: 'Industrial Dark UI',
      icon: (
        <svg viewBox="0 0 24 24" className="w-6 h-6 stroke-current fill-none stroke-[1.5]">
          <path d="M12 4c-4.4 0-7 2.2-7 6.6 1.8-1.1 3.5-1.5 5.2-.8 1 0.4 1.8 1.2 2.6 2 1.3 1.4 2.8 3 6.2 3 4.4 0 7-2.2 7-6.6-1.8 1.1-3.5 1.5-5.2.8-1-0.4-1.8-1.2-2.6-2-1.3-1.4-2.8-3-6.2-3z" />
        </svg>
      ),
    },

    // Row 4
    {
      name: 'EPSS & Threat Prioritization',
      category: 'Predictive Exploit Scoring',
      icon: (
        <svg viewBox="0 0 24 24" className="w-6 h-6 stroke-current fill-none stroke-[1.5]">
          <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
        </svg>
      ),
    },
    {
      name: 'FastAPI & Python Async',
      category: 'Threat Ingestion APIs',
      icon: (
        <svg viewBox="0 0 24 24" className="w-6 h-6 stroke-current fill-none stroke-[1.5]">
          <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
        </svg>
      ),
    },
    {
      name: 'SQL & Database Indexing',
      category: 'Telemetry Data Stores',
      icon: (
        <svg viewBox="0 0 24 24" className="w-6 h-6 stroke-current fill-none stroke-[1.5]">
          <ellipse cx="12" cy="5" rx="9" ry="3" />
          <path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3" />
          <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5" />
        </svg>
      ),
    },
    {
      name: 'Telegram Bots & Briefings',
      category: 'Alert Dispatch Pipelines',
      icon: (
        <svg viewBox="0 0 24 24" className="w-6 h-6 stroke-current fill-none stroke-[1.5]">
          <line x1="22" y1="2" x2="11" y2="13" />
          <polygon points="22 2 15 22 11 13 2 9 22 2" />
        </svg>
      ),
    },

    // Row 5
    {
      name: 'Vulnerability Scanners',
      category: 'Static & Dynamic Audits',
      icon: (
        <svg viewBox="0 0 24 24" className="w-6 h-6 stroke-current fill-none stroke-[1.5]">
          <circle cx="11" cy="11" r="8" />
          <line x1="21" y1="21" x2="16.65" y2="16.65" />
        </svg>
      ),
    },
    {
      name: 'REST & GraphQL APIs',
      category: 'System Integration',
      icon: (
        <svg viewBox="0 0 24 24" className="w-6 h-6 stroke-current fill-none stroke-[1.5]">
          <rect x="2" y="2" width="20" height="8" rx="2" ry="2" />
          <rect x="2" y="14" width="20" height="8" rx="2" ry="2" />
          <line x1="6" y1="6" x2="6.01" y2="6" />
          <line x1="6" y1="18" x2="6.01" y2="18" />
        </svg>
      ),
    },
    {
      name: 'Node.js & Runtime Internals',
      category: 'Tooling & Backend',
      icon: (
        <svg viewBox="0 0 24 24" className="w-6 h-6 stroke-current fill-none stroke-[1.5]">
          <path d="M12 2l8 4.5v9L12 20l-8-4.5v-9L12 2z" />
          <line x1="12" y1="12" x2="20" y2="7.5" />
          <line x1="12" y1="12" x2="12" y2="20" />
          <line x1="12" y1="12" x2="4" y2="7.5" />
        </svg>
      ),
    },
    {
      name: 'AI Engineering & LLMs',
      category: 'GenAI Security & Automation',
      icon: (
        <svg viewBox="0 0 24 24" className="w-6 h-6 stroke-current fill-none stroke-[1.5]">
          <path d="M12 2l2.4 6.6L21 11l-6.6 2.4L12 20l-2.4-6.6L3 11l6.6-2.4L12 2z" />
          <path d="M19 16l1 2.5 2.5 1-2.5 1-1 2.5-1-2.5-2.5-1 2.5-1 1-2.5z" />
        </svg>
      ),
    },
  ];

  return (
    <section className="mb-14">
      {/* Section Header */}
      <div className="flex items-center gap-2 mb-6">
        <h2 className="text-xs font-mono tracking-widest text-neutral-500 dark:text-neutral-400 uppercase">
          {t.skillsTitle}
        </h2>
      </div>

      {/* Grid: 4 columns across 5 rows, perfectly centered */}
      <div className="grid grid-cols-4 gap-y-8 gap-x-4 max-w-lg mx-auto py-4">
        {skills.map((skill) => (
          <div
            key={skill.name}
            onMouseEnter={() => setActiveSkill(skill.name)}
            onMouseLeave={() => setActiveSkill(null)}
            className="relative flex flex-col items-center justify-center group cursor-pointer"
          >
            {/* Icon Container with subtle glow on hover */}
            <div className="w-12 h-12 flex items-center justify-center text-neutral-500 dark:text-neutral-400 group-hover:text-neutral-900 dark:group-hover:text-white transition-all duration-200 group-hover:scale-115">
              {skill.icon}
            </div>

            {/* Hover Tooltip */}
            {activeSkill === skill.name && (
              <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 text-neutral-900 dark:text-neutral-200 text-[10px] font-mono px-2 py-0.5 rounded shadow-xl z-20 whitespace-nowrap pointer-events-none">
                <span className="font-semibold">{skill.name}</span>
                <span className="text-neutral-500 dark:text-neutral-400 ml-1.5">({skill.category})</span>
              </div>
            )}
          </div>
        ))}
      </div>
    </section>
  );
};
