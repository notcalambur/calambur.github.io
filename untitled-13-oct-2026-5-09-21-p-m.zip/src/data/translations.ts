export type Language = 'en' | 'es';

export interface Translations {
  findMeAt: string;
  aboutMeTitle: string;
  aboutMeParagraphs: string[];
  projectsTitle: string;
  currentlyBuilding: string;
  activityTitle: string;
  liveFeed: string;
  github: {
    viewProfile: string;
    contributionsTotal: string;
    less: string;
    more: string;
    contributions: string;
  };
  twitter: {
    viewProfile: string;
    recentPosts: string;
    lastPosted: string;
    tweets: {
      text: string;
      time: string;
      likes: number;
      retweets: number;
    }[];
  };
  skillsTitle: string;
  commissionsTitle: string;
  openCommissions: {
    badge: string;
    title: string;
    description: string;
    email: string;
    button: string;
    copyButton: string;
    copied: string;
    services: string[];
  };
  blogTitle: string;
  comingSoon: string;
  footerIdea: string;
  letsTalk: string;
  footerNewsletter: {
    title: string;
    badge: string;
    description: string;
    placeholder: string;
    button: string;
    redirecting: string;
    invalidEmail: string;
    readPastIssues: string;
    alreadySubscribed: string;
  };
  contactModal: {
    title: string;
    subtitle: string;
    nameLabel: string;
    emailLabel: string;
    messageLabel: string;
    sendButton: string;
    sending: string;
    sent: string;
    copyEmail: string;
    copied: string;
  };
  projects: {
    sentinelBench: {
      title: string;
      subtitle: string;
      description: string;
    };
    vibeChecker: {
      title: string;
      subtitle: string;
      description: string;
    };
  };
  blog: {
    minRead: string;
    searchPlaceholder: string;
    noArticlesFound: string;
    noArticlesDesc: string;
    clearSearch: string;
    allFilter: string;
    filterByTag: string;
    item1: {
      title: string;
      desc: string;
      date: string;
      tags: string[];
    };
    item2: {
      title: string;
      desc: string;
      date: string;
      tags: string[];
    };
    item3: {
      title: string;
      desc: string;
      date: string;
      tags: string[];
    };
  };
}

export const translations: Record<Language, Translations> = {
  en: {
    findMeAt: "FIND ME AT",
    aboutMeTitle: "ABOUT ME",
    aboutMeParagraphs: [
      "I'm Calambur, a Cybersecurity Blue Team Analyst and AI Engineer.",
      "Currently working in cybersecurity blue team operations while actively developing AI side projects.",
      "Passionate about building and breaking systems, solving intricate security challenges, engaging on social media, and writing technical blogs.",
      "I merge the analytical defense mindset of modern SOC telemetry with practical AI engineering to create resilient, automated security tools."
    ],
    projectsTitle: "PROJECTS",
    currentlyBuilding: "CURRENTLY BUILDING",
    activityTitle: "ACTIVITY",
    liveFeed: "LIVE FEED",
    github: {
      viewProfile: "View profile",
      contributionsTotal: "85 contributions in the last year",
      less: "Less",
      more: "More",
      contributions: "contributions"
    },
    twitter: {
      viewProfile: "View profile",
      recentPosts: "Recent posts",
      lastPosted: "Active on X",
      tweets: [
        {
          text: "Launching Sentinel-Bench 🛡️: Personal Cyber Threat Intelligence lab. Filters 96% of public NVD noise and prioritizes CVEs with CISA KEV + EPSS. https://sentinel-bench.vercel.app/",
          time: "2d ago",
          likes: 42,
          retweets: 11
        },
        {
          text: "Introducing VibeChecker ⚡: Free security scanner for vibe-coded apps (Cursor, Lovable, Bolt, Replit). Finds critical vulnerabilities with tailored AI fix prompts before attackers do.",
          time: "1w ago",
          likes: 87,
          retweets: 24
        },
        {
          text: "Building by breaking first: telemetry in real time doesn't lie. Shipping blue team detection tools, autonomous triage agents, and AI side projects.",
          time: "2w ago",
          likes: 63,
          retweets: 15
        },
        {
          text: "Update on Sentinel-Bench: automatic remediation extraction from vendor advisories and direct normalization with CISA KEV catalog. Open source on GitHub.",
          time: "3w ago",
          likes: 38,
          retweets: 9
        }
      ]
    },
    skillsTitle: "SKILLS & TOOLS",
    commissionsTitle: "OPEN COMMISSIONS",
    openCommissions: {
      badge: "AVAILABLE FOR COMMISSIONS",
      title: "Open Commissions",
      description: "Available for contract work, specialized blue team tooling, threat intelligence integrations, and custom AI security pipelines. Let's build something secure and resilient.",
      email: "mr.indie.cybersec@gmail.com",
      button: "Contact for Work",
      copyButton: "Copy Email",
      copied: "Email Copied!",
      services: [
        "Cybersecurity Blue Team Defense & Telemetry",
        "Threat Intelligence Aggregation (CISA KEV / EPSS / NVD)",
        "AI Agents for Automated Vulnerability Triage",
        "Security Architecture & Code Audits"
      ]
    },
    blogTitle: "BLOG",
    comingSoon: "Coming Soon",
    footerIdea: "Have a project or security inquiry?",
    letsTalk: "Let's talk",
    footerNewsletter: {
      title: "JOIN NEWSLETTER",
      badge: "SUBSTACK",
      description: "Subscribe for deep-dives into blue team operations, threat intelligence automation, and AI side projects delivered straight to your inbox.",
      placeholder: "your.email@domain.com",
      button: "Subscribe",
      redirecting: "Opening Substack to confirm subscription...",
      invalidEmail: "Please enter a valid email address.",
      readPastIssues: "Read issues on Substack: @notcalambur",
      alreadySubscribed: "Subscribed via Substack!"
    },
    contactModal: {
      title: "CONTACT CALAMBUR",
      subtitle: "Open Commissions & Inquiries",
      nameLabel: "Your Name",
      emailLabel: "Your Email",
      messageLabel: "Project Details / Message",
      sendButton: "Send Inquiry",
      sending: "Sending...",
      sent: "Message sent! I'll get back to you soon.",
      copyEmail: "Copy Direct Email",
      copied: "Email Copied!"
    },
    projects: {
      sentinelBench: {
        title: "Sentinel-Bench",
        subtitle: "Cyber Threat Intelligence Lab",
        description: "Personal Cyber Threat Intelligence lab — ingest CVEs, score priority (CISA KEV, NVD, EPSS, GHSA, MSRC), summarize threat landscapes, and send automated Telegram briefings with an industrial HUD Astro dashboard."
      },
      vibeChecker: {
        title: "VibeChecker",
        subtitle: "AI Vibe Coding Security Scanner",
        description: "Free security scanner for vibe-coded apps (Cursor, Lovable, Bolt, Replit). Finds critical vulnerabilities before they become breaches with tailored AI fix prompts."
      }
    },
    blog: {
      minRead: "min read",
      searchPlaceholder: "Search articles by title or tags...",
      noArticlesFound: "No articles found",
      noArticlesDesc: "Try searching with different keywords or clearing your active tag filter.",
      clearSearch: "Clear search",
      allFilter: "All",
      filterByTag: "Filter by tag",
      item1: {
        title: "Minimalist Workspace 2026",
        desc: "Terminal setup, dark mode ergonomics, and daily workflow essentials.",
        date: "Coming Soon",
        tags: ["workspace", "minimalism", "terminal", "ergonomics"]
      },
      item2: {
        title: "Ergonomic Focus Station",
        desc: "Ultrawide single-monitor setup and zero-distraction layout engineering.",
        date: "Coming Soon",
        tags: ["ultrawide", "focus", "hardware", "productivity"]
      },
      item3: {
        title: "Custom Mechanical Keyboards",
        desc: "Lubed linear switches, custom keycaps, and sound profile calibration.",
        date: "Coming Soon",
        tags: ["keyboards", "custom", "tactile", "gear"]
      }
    }
  },
  es: {
    findMeAt: "FIND ME AT",
    aboutMeTitle: "ABOUT ME",
    aboutMeParagraphs: [
      "Soy Calambur, analista en ciberseguridad blue team y AI engineer.",
      "Actualmente trabajo en cybersecurity blue team mientras desarrollo side projects impulsados por inteligencia artificial.",
      "Me apasiona tanto construir como destruir cosas, resolver problemas, hacer engaging en redes sociales y como así también escribir blogs.",
      "Combino la mentalidad analítica y defensiva de la ciberseguridad con la velocidad y automatización que brinda la IA moderna para crear sistemas robustos y de alto impacto."
    ],
    projectsTitle: "PROJECTS",
    currentlyBuilding: "CURRENTLY BUILDING",
    activityTitle: "ACTIVITY",
    liveFeed: "LIVE FEED",
    github: {
      viewProfile: "View profile",
      contributionsTotal: "85 contribuciones en el último año",
      less: "Menos",
      more: "Más",
      contributions: "contribuciones"
    },
    twitter: {
      viewProfile: "View profile",
      recentPosts: "Posteos recientes",
      lastPosted: "Activo en X",
      tweets: [
        {
          text: "Lanzando Sentinel-Bench 🛡️: Laboratorio personal de Cyber Threat Intelligence. Filtra el 96% de ruido de NVD y prioriza CVEs con CISA KEV + EPSS. https://sentinel-bench.vercel.app/",
          time: "hace 2d",
          likes: 42,
          retweets: 11
        },
        {
          text: "Presentando VibeChecker ⚡: Scanner gratuito de seguridad para apps desarrolladas con vibe coding (Cursor, Lovable, Bolt, Replit). Encuentra vulnerabilidades críticas con prompts de fix para tu agente de IA.",
          time: "hace 1sem",
          likes: 87,
          retweets: 24
        },
        {
          text: "Construyendo y rompiendo sistemas en blue team: la telemetría en tiempo real no miente. Nuevos side projects de ciberseguridad e IA en camino.",
          time: "hace 2sem",
          likes: 63,
          retweets: 15
        },
        {
          text: "Actualización en Sentinel-Bench: extracción de remediaciones automáticas desde vendor advisories y normalización con CISA KEV. Código libre en GitHub.",
          time: "hace 3sem",
          likes: 38,
          retweets: 9
        }
      ]
    },
    skillsTitle: "SKILLS & TOOLS",
    commissionsTitle: "OPEN COMMISSIONS",
    openCommissions: {
      badge: "DISPONIBLE PARA PROYECTOS",
      title: "Open Commissions",
      description: "Disponible para contratos técnicos, herramientas especializadas de blue team, integraciones de threat intelligence y pipelines de seguridad con IA. Construyamos herramientas sólidas y seguras.",
      email: "mr.indie.cybersec@gmail.com",
      button: "Contactar por Proyectos",
      copyButton: "Copiar Correo",
      copied: "¡Correo Copiado!",
      services: [
        "Ciberdefensa Blue Team y Telemetría SOC",
        "Agregación de Threat Intelligence (CISA KEV / EPSS / NVD)",
        "Agentes de IA para Triage Automatizado de Vulnerabilidades",
        "Auditorías de Código y Arquitectura Segura"
      ]
    },
    blogTitle: "BLOG",
    comingSoon: "Próximamente",
    footerIdea: "¿Tienes un proyecto o consulta de seguridad?",
    letsTalk: "Hablemos",
    footerNewsletter: {
      title: "UNIRTE AL NEWSLETTER",
      badge: "SUBSTACK",
      description: "Suscríbete para recibir análisis de blue team, telemetría de ciberdefensa y side projects de IA directamente en tu correo vía Substack.",
      placeholder: "tu.correo@dominio.com",
      button: "Suscribirse",
      redirecting: "Abriendo Substack para confirmar suscripción...",
      invalidEmail: "Por favor ingresa un correo electrónico válido.",
      readPastIssues: "Lee artículos anteriores en Substack: @notcalambur",
      alreadySubscribed: "¡Suscrito en Substack!"
    },
    contactModal: {
      title: "CONTACTAR A CALAMBUR",
      subtitle: "Open Commissions y Consultas",
      nameLabel: "Tu Nombre",
      emailLabel: "Tu Correo",
      messageLabel: "Detalles del Proyecto / Mensaje",
      sendButton: "Enviar Consulta",
      sending: "Enviando...",
      sent: "¡Mensaje enviado! Te responderé a la brevedad.",
      copyEmail: "Copiar Correo Directo",
      copied: "¡Correo Copiado!"
    },
    projects: {
      sentinelBench: {
        title: "Sentinel-Bench",
        subtitle: "Cyber Threat Intelligence Lab",
        description: "Laboratorio personal de Cyber Threat Intelligence — CISA KEV + NVD + EPSS + GHSA + MSRC, scoring priorizado, briefing en Telegram y dashboard en Astro."
      },
      vibeChecker: {
        title: "VibeChecker",
        subtitle: "AI Vibe Coding Security Scanner",
        description: "Scanner gratuito de seguridad para apps vibe-coded (Cursor, Lovable, Bolt, Replit). Encuentra vulnerabilidades críticas antes de sufrir brechas, con prompts de fix para tu agente de IA."
      }
    },
    blog: {
      minRead: "min de lectura",
      searchPlaceholder: "Buscar artículos por título o tags...",
      noArticlesFound: "No se encontraron artículos",
      noArticlesDesc: "Prueba buscando con otras palabras clave o eliminando el filtro de tags.",
      clearSearch: "Limpiar búsqueda",
      allFilter: "Todos",
      filterByTag: "Filtrar por tag",
      item1: {
        title: "Setup Minimalista 2026",
        desc: "Configuración de terminal, ergonomía en modo oscuro y herramientas diarias.",
        date: "Próximamente",
        tags: ["workspace", "minimalismo", "terminal", "ergonomía"]
      },
      item2: {
        title: "Estación de Trabajo Focus",
        desc: "Monitoreo ultrawide curvo y distribución del espacio sin distracciones.",
        date: "Próximamente",
        tags: ["ultrawide", "focus", "hardware", "productividad"]
      },
      item3: {
        title: "Teclados Mecánicos Custom",
        desc: "Switches lineales lubricados, keycaps artesanales y calibración de sonido.",
        date: "Próximamente",
        tags: ["teclados", "custom", "táctil", "hardware"]
      }
    }
  }
};
